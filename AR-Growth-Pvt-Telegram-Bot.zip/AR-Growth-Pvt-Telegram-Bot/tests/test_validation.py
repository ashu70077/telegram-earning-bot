from decimal import Decimal

import pytest

from bot.validation import is_valid_upi_id, parse_amount


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("200", Decimal("200.00")),
        ("1,234.5", Decimal("1234.50")),
        ("1.00", Decimal("1.00")),
    ],
)
def test_parse_amount_valid(raw: str, expected: Decimal) -> None:
    assert parse_amount(raw) == expected


@pytest.mark.parametrize("raw", ["0", "-1", "1000001", "1.001", "NaN", "not money"])
def test_parse_amount_rejects_invalid_or_unsafe_values(raw: str) -> None:
    with pytest.raises(ValueError):
        parse_amount(raw)


@pytest.mark.parametrize("raw", ["name@bank", "1234567890@upi"])
def test_valid_upi_ids(raw: str) -> None:
    assert is_valid_upi_id(raw)


@pytest.mark.parametrize("raw", ["", "name@", "name@@bank", "name bank@bank", "name@bank\n"])
def test_invalid_upi_ids(raw: str) -> None:
    assert not is_valid_upi_id(raw)
