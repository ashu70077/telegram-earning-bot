from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import uuid4

import pytest
from sqlalchemy import func, select

from bot.db import SessionFactory
from bot.models import (
    ClaimPool,
    DailyClaim,
    Deposit,
    Order,
    Product,
    User,
    VIPEntitlement,
    VIPPlan,
    WalletEntry,
)
from bot.services import (
    add_claim_pool_funding,
    buy_product,
    buy_vip_plan,
    create_deposit,
    get_entitlement_claim_state,
    mark_withdrawal_paid,
    mark_daily_claim_paid,
    request_withdrawal,
    request_daily_claim,
    reject_daily_claim,
    review_deposit,
    review_withdrawal,
    set_setting,
)


def _new_user_id() -> int:
    return 4_000_000_000_000_000 + uuid4().int % 100_000_000_000


@pytest.mark.asyncio
async def test_verified_deposit_is_once_and_referral_commission_is_ledgered() -> None:
    async with SessionFactory() as session:
        transaction = await session.begin()
        try:
            referrer_id = _new_user_id()
            user_id = _new_user_id()
            session.add_all(
                [
                    User(telegram_id=referrer_id, first_name="test-ref", balance=Decimal("0")),
                    User(telegram_id=user_id, first_name="test-user", referred_by=referrer_id, balance=Decimal("0")),
                ]
            )
            await session.flush()
            await set_setting(session, "referral_commission_percent", "10")
            deposit = await create_deposit(session, user_id, Decimal("200.00"), f"T{uuid4().hex[:24]}")
            approved, paid_referrer, commission = await review_deposit(
                session, deposit.id, 1, True
            )
            assert approved.status == "approved"
            assert paid_referrer == referrer_id
            assert commission == Decimal("20.00")
            assert (await session.get(User, user_id)).balance == Decimal("200.00")
            assert (await session.get(User, referrer_id)).balance == Decimal("20.00")
            count = await session.scalar(
                select(func.count()).select_from(WalletEntry).where(
                    WalletEntry.reference_type == "deposit", WalletEntry.reference_id == deposit.id
                )
            )
            assert count == 2
            with pytest.raises(ValueError, match="already been reviewed"):
                await review_deposit(session, deposit.id, 1, True)
            with pytest.raises(ValueError, match="already been submitted"):
                await create_deposit(session, _new_user_id(), Decimal("200.00"), deposit.utr)
        finally:
            await transaction.rollback()


@pytest.mark.asyncio
async def test_rejected_withdrawal_refunds_reserved_balance_and_paid_status_is_explicit() -> None:
    async with SessionFactory() as session:
        transaction = await session.begin()
        try:
            user_id = _new_user_id()
            session.add(User(telegram_id=user_id, first_name="test-user", balance=Decimal("500.00")))
            await session.flush()
            request = await request_withdrawal(session, user_id, Decimal("200.00"), "test@bank")
            assert (await session.get(User, user_id)).balance == Decimal("300.00")
            await review_withdrawal(session, request.id, 1, "reject", "Test rejection")
            assert request.status == "rejected"
            assert (await session.get(User, user_id)).balance == Decimal("500.00")

            second = await request_withdrawal(session, user_id, Decimal("100.00"), "test@bank")
            await review_withdrawal(session, second.id, 1, "approve")
            assert second.status == "approved"
            paid = await mark_withdrawal_paid(session, second.id, 1, "PAYMENT-TEST-REF")
            assert paid.status == "paid"
            assert paid.payment_reference == "PAYMENT-TEST-REF"
            with pytest.raises(ValueError, match="Only an approved"):
                await mark_withdrawal_paid(session, second.id, 1, "DUPLICATE")
        finally:
            await transaction.rollback()


@pytest.mark.asyncio
async def test_product_purchase_updates_balance_stock_and_history() -> None:
    async with SessionFactory() as session:
        transaction = await session.begin()
        try:
            user_id = _new_user_id()
            user = User(telegram_id=user_id, first_name="test-user", balance=Decimal("100.00"))
            product = Product(name="test product", description="test", price=Decimal("40.00"), stock_quantity=1, is_active=True)
            session.add_all([user, product])
            await session.flush()
            order = await buy_product(session, user_id, product.id)
            assert order.amount == Decimal("40.00")
            assert user.balance == Decimal("60.00")
            assert product.stock_quantity == 0
            with pytest.raises(ValueError, match="out of stock"):
                await buy_product(session, user_id, product.id)
        finally:
            await transaction.rollback()


@pytest.mark.asyncio
async def test_vip_plan_can_only_be_purchased_once_per_user() -> None:
    async with SessionFactory() as session:
        transaction = await session.begin()
        try:
            user_id = _new_user_id()
            plan = VIPPlan(
                name="test plan",
                price=Decimal("20.00"),
                duration_days=30,
                is_active=True,
                sort_order=uuid4().int % 2_000_000_000,
            )
            user = User(telegram_id=user_id, first_name="test-user", balance=Decimal("100.00"))
            session.add_all([plan, user])
            await session.flush()
            first = await buy_vip_plan(session, user_id, plan.id)
            assert first.plan_id == plan.id
            with pytest.raises(ValueError, match="already purchased"):
                await buy_vip_plan(session, user_id, plan.id)
            assert user.balance == Decimal("80.00")
            other_plan = VIPPlan(
                name="another test plan",
                price=Decimal("20.00"),
                duration_days=30,
                is_active=True,
                sort_order=uuid4().int % 2_000_000_000,
            )
            session.add(other_plan)
            await session.flush()
            second = await buy_vip_plan(session, user_id, other_plan.id)
            assert second.plan_id == other_plan.id
            assert user.balance == Decimal("60.00")
            count = await session.scalar(
                select(func.count()).select_from(WalletEntry).where(
                    WalletEntry.user_id == user_id, WalletEntry.kind == "vip_purchase"
                )
            )
            assert count == 2
        finally:
            await transaction.rollback()


async def _create_claim_entitlement(session, user_id: int, cap: Decimal = Decimal("15.00")) -> VIPEntitlement:
    pool = await session.get(ClaimPool, 1)
    if pool is None:
        session.add(ClaimPool(id=1, available_funds=Decimal("0.00")))
    plan = VIPPlan(
        name="claim test plan",
        price=Decimal("200.00"),
        duration_days=30,
        is_active=True,
        sort_order=uuid4().int % 2_000_000_000,
        daily_claim_amount=Decimal("15.00"),
        claim_interval_hours=24,
        claim_max_amount=cap,
    )
    session.add_all(
        [
            plan,
            User(telegram_id=user_id, first_name="claim-test", balance=Decimal("200.00")),
        ]
    )
    await session.flush()
    await buy_vip_plan(session, user_id, plan.id)
    order = await session.scalar(
        select(Order).where(Order.user_id == user_id, Order.vip_plan_id == plan.id)
    )
    assert order is not None
    entitlement = await session.get(VIPEntitlement, order.id)
    assert entitlement is not None
    return entitlement


@pytest.mark.asyncio
async def test_daily_claim_requires_funds_and_actual_paid_reference() -> None:
    async with SessionFactory() as session:
        transaction = await session.begin()
        try:
            user_id = _new_user_id()
            entitlement = await _create_claim_entitlement(session, user_id)
            with pytest.raises(ValueError, match="not enough verified funds"):
                await request_daily_claim(session, user_id, entitlement.order_id)

            await add_claim_pool_funding(
                session, 1, Decimal("30.00"), f"FUND-{uuid4().hex[:20]}"
            )
            claim, pool_balance = await request_daily_claim(
                session, user_id, entitlement.order_id
            )
            assert claim.status == "pending"
            assert claim.amount == Decimal("15.00")
            assert pool_balance == Decimal("15.00")
            user = await session.get(User, user_id)
            assert user is not None and user.balance == Decimal("0.00")
            with pytest.raises(ValueError, match="already awaiting payout"):
                await request_daily_claim(session, user_id, entitlement.order_id)

            paid_at = datetime.now(timezone.utc)
            paid = await mark_daily_claim_paid(
                session, claim.id, 1, f"UPI-{uuid4().hex[:20]}", now=paid_at
            )
            assert paid.status == "paid"
            assert paid.paid_at == paid_at
            assert user.balance == Decimal("0.00")
            with pytest.raises(ValueError, match="next claim is available"):
                await request_daily_claim(
                    session,
                    user_id,
                    entitlement.order_id,
                    now=paid_at + timedelta(hours=23),
                )
            with pytest.raises(ValueError, match="maximum claim amount"):
                await request_daily_claim(
                    session,
                    user_id,
                    entitlement.order_id,
                    now=paid_at + timedelta(hours=24),
                )
            state = await get_entitlement_claim_state(session, entitlement, paid_at)
            assert state["paid_total"] == Decimal("15.00")
        finally:
            await transaction.rollback()


@pytest.mark.asyncio
async def test_rejected_claim_releases_reserved_pool_funds() -> None:
    async with SessionFactory() as session:
        transaction = await session.begin()
        try:
            user_id = _new_user_id()
            entitlement = await _create_claim_entitlement(session, user_id)
            await add_claim_pool_funding(
                session, 1, Decimal("15.00"), f"FUND-{uuid4().hex[:20]}"
            )
            claim, available = await request_daily_claim(
                session, user_id, entitlement.order_id
            )
            assert available == Decimal("0.00")

            rejected = await reject_daily_claim(
                session, claim.id, 1, "Payout details could not be verified."
            )
            pool = await session.get(ClaimPool, 1)
            assert rejected.status == "rejected"
            assert pool is not None and pool.available_funds == Decimal("15.00")
            state = await get_entitlement_claim_state(session, entitlement)
            assert state["reason"] == "eligible"
            assert state["paid_total"] == Decimal("0.00")
            count = await session.scalar(
                select(func.count()).select_from(DailyClaim).where(
                    DailyClaim.user_id == user_id
                )
            )
            assert count == 1
        finally:
            await transaction.rollback()
