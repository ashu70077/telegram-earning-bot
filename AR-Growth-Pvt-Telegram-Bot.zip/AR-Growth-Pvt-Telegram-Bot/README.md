# AR Growth Pvt. Telegram Bot

A Python Telegram bot built with aiogram 3 and PostgreSQL. It provides a product catalogue, ten editable VIP membership plans, account balances, manual UPI deposit verification, withdrawal review and payout tracking, referral commissions, admin reports, and an admin activity log.

The customer menu focuses on VIP memberships, daily-claim requests, deposits, withdrawals, account details, referrals, and transaction history. Product/service editing remains available to the admin, but Products is hidden from the customer menu. The bot does not initiate UPI payments or independently verify bank transfers. An administrator must compare each submitted UTR with the receiving account before approving a deposit. Deposits remain pending and do not change a balance until approval. Daily claims are conditional requests, not guaranteed returns or wallet credits; they are paid only after funds are recorded in the claim pool and an administrator records the actual payout reference.

## Replit setup

The Replit Secrets `TELEGRAM_BOT_TOKEN` and `ADMIN_TELEGRAM_ID` are already configured for this project. Do not paste either value into source code or chat. The project PostgreSQL database provides `DATABASE_URL`.

1. Open the Shell and install Python dependencies if Replit has not already installed them:

   ```bash
   python -m pip install -r requirements.txt
   ```

2. Apply the initial PostgreSQL schema in the development database:

   ```bash
   alembic upgrade head
   ```

3. Seed the ten default plans and initial settings (safe to re-run):

   ```bash
   python -m bot.seed
   ```

4. Start the **AR Growth Pvt. Bot** workflow. Or run it directly:

   ```bash
   python -m bot.main
   ```

5. Open the bot in Telegram and send `/start`. The configured admin Telegram ID sees **Admin Panel** and can configure UPI details, QR code, support contact, the default 20% referral commission, product/service listings, and VIP plan prices and names.

For daily claims, the administrator must open **Admin Panel → Claims & Funds** and record funds only after confirming that the money has cleared in the real payout account. The claim pool starts at ₹0, so claims cannot be requested until funds are recorded.

Use `/cancel` to exit an in-progress form and `/status` to see recent deposit and withdrawal request states.

## Payment and account safeguards

- Deposits require an amount and UTR. UTRs are normalized and globally unique in PostgreSQL. Duplicate UTR submissions are rejected.
- Only an admin callback can approve or reject a pending deposit. Approving credits the account and any configured referral commission in the same database transaction. Repeated approvals are blocked.
- Withdrawal amounts are reserved from available balance when requested. Rejection refunds the amount; approval means awaiting payout, not paid. The admin must send the UPI transfer outside the bot and then mark it paid with a payment reference.
- Daily claims reserve funds from a separate admin-recorded payout pool. A request remains pending and is not credited to the user's wallet; the admin must send the actual payout and record its reference before the claim shows as paid. Rejection releases the reservation back to the pool.
- The bot tracks daily claim eligibility, 24-hour intervals, expiry, and the configured maximum per entitlement. Claim settings are snapshotted when purchased; later rule edits apply to new purchases only.
- 24 hours is shown as a processing target, not a guarantee.
- Product deletion removes it from the active catalogue while retaining prior purchase history.
- Account records are keyed by Telegram user ID. Admin actions are permission-checked on each command and callback.
- The bot logs admin actions, but does not store or display the Telegram token.

## VIP plans and catalogue

The first seed creates `VIP Plan 1` through `VIP Plan 10`, priced from ₹200 to ₹2,000 in ₹200 increments, each initially lasting 30 days. Plan 1 has a configured claim rule of up to ₹15 every 24 hours, with a ₹450 maximum. This is conditional on available recorded pool funds and eligibility; it is not guaranteed income or a guaranteed return. The user must make a claim request, and the admin marks it paid only after the real payout is sent. Names, prices, duration, and claim rules can be edited in Telegram. A user can purchase each plan only once; the VIP page and account screen show price, purchase state, claim progress, and expiry. The referral commission is 20% by default and is credited only after an administrator verifies a referred user's deposit; the admin can change it.

The product catalogue intentionally starts empty. Add only real products or services you provide, with accurate descriptions, prices, and stock. The bot never invents a catalogue.

## Database changes

Database schema changes are managed by Alembic. Apply migrations manually before starting the bot; the long-running polling process does not run DDL on startup.

```bash
alembic upgrade head
```

The migration filters are scoped to the `argrowth_` table prefix, so the bot schema does not alter the existing API service tables.

## Tests

```bash
pytest -q
```

The validation tests are self-contained. Service tests use PostgreSQL and roll their test data back at the end of each test.
