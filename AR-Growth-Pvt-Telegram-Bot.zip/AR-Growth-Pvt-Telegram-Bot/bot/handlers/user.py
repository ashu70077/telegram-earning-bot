from decimal import Decimal

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import desc, select

from bot.config import get_settings
from bot.db import SessionFactory
from bot.keyboards import (
    BTN_ACCOUNT,
    BTN_ADMIN,
    BTN_DAILY_CLAIM,
    BTN_DEPOSIT,
    BTN_HISTORY,
    BTN_PRODUCTS,
    BTN_REFERRAL,
    BTN_SUPPORT,
    BTN_VIP,
    BTN_WITHDRAW,
    user_menu,
)
from bot.models import (
    ClaimPool,
    DailyClaim,
    Deposit,
    Order,
    Product,
    User,
    VIPEntitlement,
    VIPMembership,
    VIPPlan,
    WalletEntry,
    Withdrawal,
)
from bot.services import (
    buy_product,
    buy_vip_plan,
    create_deposit,
    ensure_user,
    get_entitlement_claim_state,
    get_setting,
    request_daily_claim,
    request_withdrawal,
    utcnow,
)
from bot.states import DepositFlow, WithdrawalFlow
from bot.validation import is_valid_upi_id, parse_amount

router = Router()
MIN_AMOUNT = Decimal("1.00")
MAX_AMOUNT = Decimal("1000000.00")
DEPOSIT_STATUS = {
    "pending": "⏳ Pending verification",
    "approved": "✅ Verified · balance credited",
    "rejected": "❌ Rejected",
}
WITHDRAWAL_STATUS = {
    "pending": "⏳ Under review · amount reserved",
    "approved": "🏦 Approved · awaiting payout",
    "paid": "✅ Paid",
    "rejected": "❌ Rejected · balance refunded",
}
CLAIM_STATUS = {
    "pending": "⏳ Pending payout · funds reserved",
    "paid": "✅ Paid · verified reference recorded",
    "rejected": "❌ Rejected · reserved funds released",
}
WALLET_ENTRY_LABELS = {
    "deposit": "Verified deposit",
    "referral_commission": "Referral commission",
    "withdrawal_reserved": "Withdrawal reserved",
    "withdrawal_refund": "Withdrawal refund",
    "product_purchase": "Product purchase",
    "vip_purchase": "VIP plan purchase",
}


def money(amount: Decimal) -> str:
    return f"₹{amount:,.2f}"


async def notify_admin(bot: Bot, text: str, keyboard=None) -> None:
    admin_id = get_settings().admin_telegram_id
    try:
        await bot.send_message(admin_id, text, reply_markup=keyboard)
    except Exception:
        # The database request is authoritative; admin can still find it in the panel.
        return


async def get_or_create_user(message: Message, start_arg: str | None = None) -> User:
    telegram_user = message.from_user
    referrer = None
    if start_arg and start_arg.isdigit():
        referrer = int(start_arg)
    async with SessionFactory() as session:
        async with session.begin():
            return await ensure_user(
                session,
                telegram_user.id,
                telegram_user.username,
                telegram_user.first_name or "",
                referrer,
            )


@router.message(CommandStart())
async def start(message: Message, command: CommandObject) -> None:
    user = await get_or_create_user(message, command.args)
    is_admin = user.telegram_id == get_settings().admin_telegram_id
    await message.answer(
        "👋 Welcome to AR Growth Pvt.\n\n"
        "👑 Browse our editable VIP membership plans\n"
        "💎 View eligible funded daily-claim requests\n"
        "💳 Submit a UPI deposit for manual verification\n"
        "💸 Request a withdrawal and track each status\n"
        "📜 Review your wallet activity and transaction history\n\n"
        "VIP plans provide membership access; they do not promise profits or investment returns.",
        reply_markup=user_menu(is_admin),
    )


@router.message(Command("cancel"))
async def cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Cancelled.", reply_markup=user_menu(message.from_user.id == get_settings().admin_telegram_id))


@router.message(F.text == BTN_ACCOUNT)
async def account(message: Message) -> None:
    async with SessionFactory() as session:
        user = await session.get(User, message.from_user.id)
        membership = await session.get(VIPMembership, message.from_user.id)
        entitlements = list(
            (
                await session.scalars(
                    select(VIPEntitlement)
                    .where(VIPEntitlement.user_id == message.from_user.id)
                    .order_by(desc(VIPEntitlement.purchased_at))
                    .limit(10)
                )
            ).all()
        )
        purchases = list(
            (
                await session.scalars(
                    select(Order)
                    .where(Order.user_id == message.from_user.id, Order.vip_plan_id.is_not(None))
                    .order_by(desc(Order.created_at))
                    .limit(10)
                )
            ).all()
        )
        if user is None:
            await message.answer("Send /start to create your account.")
            return
        active = membership and membership.expires_at > utcnow()
        vip_status = (
            f"✅ {membership.plan_name}\n   Valid till {membership.expires_at:%d %b %Y, %H:%M} UTC"
            if active
            else f"Expired: {membership.plan_name}" if membership else "No plan purchased"
        )
        purchase_history = "\n".join(
            f"• {order.product_name.removeprefix('VIP membership: ')} — {money(order.amount)} · "
            f"{order.created_at:%d %b %Y, %H:%M} UTC"
            for order in purchases
        ) or "No VIP plan purchases yet."
        claim_lines = []
        for entitlement in entitlements:
            if entitlement.daily_claim_amount <= 0:
                continue
            state = await get_entitlement_claim_state(session, entitlement)
            pending = state["pending"]
            if pending is not None:
                next_claim_text = f"Pending payout request #{pending.id}"
            elif state["reason"] == "expired":
                next_claim_text = "Claim period expired"
            elif state["reason"] == "cap_reached":
                next_claim_text = "Maximum claim amount reached"
            elif state["reason"] == "cooldown":
                next_claim_text = f"Next eligible: {state['next_claim_at']:%d %b %Y, %H:%M} UTC"
            elif state["reason"] == "eligible":
                next_claim_text = "Eligible now, subject to funded pool"
            else:
                next_claim_text = "Claims are not enabled"
            claim_lines.append(
                f"• {entitlement.plan_name}: {state['remaining_days']} days remaining\n"
                f"  Paid: {money(state['paid_total'])} / max {money(entitlement.claim_max_amount)}\n"
                f"  Next claim: {next_claim_text}"
            )
        await message.answer(
            "👤 MY ACCOUNT\n"
            "━━━━━━━━━━━━━━\n"
            f"🆔 Telegram ID: {user.telegram_id}\n"
            f"💰 Available wallet balance: {money(user.balance)}\n"
            f"👑 Current VIP status: {vip_status}\n\n"
            f"📋 MY VIP PLAN PURCHASES\n{purchase_history}\n\n"
            "💎 DAILY CLAIM PROGRESS\n"
            f"{chr(10).join(claim_lines) if claim_lines else 'No daily-claim entitlements.'}\n\n"
            "Your balance changes only through verified deposits, referral credits, and recorded wallet transactions."
        )


@router.message(F.text == BTN_VIP)
async def vip_plans(message: Message) -> None:
    async with SessionFactory() as session:
        plans = list(
            (await session.scalars(select(VIPPlan).where(VIPPlan.is_active.is_(True)).order_by(VIPPlan.sort_order))).all()
        )
        purchased_plan_ids = set(
            (
                await session.scalars(
                    select(Order.vip_plan_id).where(
                        Order.user_id == message.from_user.id,
                        Order.vip_plan_id.is_not(None),
                    )
                )
            ).all()
        )
        membership = await session.get(VIPMembership, message.from_user.id)
        if membership is not None:
            purchased_plan_ids.add(membership.plan_id)
        if not plans:
            await message.answer("No VIP plans are currently available.")
            return
        buttons = []
        available_plans = [plan for plan in plans if plan.id not in purchased_plan_ids]
        for index in range(0, len(available_plans), 2):
            row = [
                InlineKeyboardButton(
                    text=f"👑 {plan.name[:14]} · {money(plan.price)}",
                    callback_data=f"buyvip:{plan.id}",
                )
                for plan in available_plans[index : index + 2]
            ]
            buttons.append(row)
        plan_lines = "\n".join(
            f"• {plan.name} — {money(plan.price)} · {plan.duration_days} days · "
            f"{'✅ Purchased' if plan.id in purchased_plan_ids else 'Available'}\n"
            + (
                f"  Claim rule: up to {money(plan.daily_claim_amount)} every "
                f"{plan.claim_interval_hours}h · max {money(plan.claim_max_amount)}\n"
                if plan.daily_claim_amount > 0 and plan.claim_max_amount > 0
                else "  Daily claim: Not configured\n"
            )
            for plan in plans
        )
        reply_markup = InlineKeyboardMarkup(inline_keyboard=buttons) if buttons else None
        await message.answer(
            "👑 VIP MEMBERSHIP PLANS\n"
            "━━━━━━━━━━━━━━\n"
            f"{plan_lines}\n\n"
            "Each plan can be purchased once per account. Selecting a plan deducts the displayed price from your available wallet balance.\n"
            "Claims are conditional, not guaranteed. A request requires an active entitlement and available funds recorded in the payout pool. It stays pending until the administrator confirms an actual payment.",
            reply_markup=reply_markup,
        )


@router.callback_query(F.data.startswith("buyvip:"))
async def buy_vip(callback: CallbackQuery) -> None:
    try:
        plan_id = int(callback.data.split(":", 1)[1])
        async with SessionFactory() as session:
            async with session.begin():
                membership = await buy_vip_plan(session, callback.from_user.id, plan_id)
        await callback.message.answer(
            "✅ VIP PLAN ACTIVE\n"
            "━━━━━━━━━━━━━━\n"
            f"👑 Plan: {membership.plan_name}\n"
            f"📅 Valid until: {membership.expires_at:%d %b %Y, %H:%M} UTC\n"
            "This purchase is recorded in My Account and History."
        )
        await callback.answer("Plan purchased")
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
    except Exception:
        await callback.answer("Could not complete the purchase. Please try again.", show_alert=True)


@router.message(F.text == BTN_DAILY_CLAIM)
async def daily_claim_menu(message: Message) -> None:
    now = utcnow()
    async with SessionFactory() as session:
        entitlements = list(
            (
                await session.scalars(
                    select(VIPEntitlement)
                    .where(
                        VIPEntitlement.user_id == message.from_user.id,
                        VIPEntitlement.daily_claim_amount > 0,
                        VIPEntitlement.expires_at > now,
                    )
                    .order_by(VIPEntitlement.expires_at)
                )
            ).all()
        )
        pool = await session.get(ClaimPool, 1)
        available_funds = pool.available_funds if pool else Decimal("0.00")
        buttons = []
        lines = ["💎 DAILY CLAIM STATUS", "━━━━━━━━━━━━━━"]
        for entitlement in entitlements:
            state = await get_entitlement_claim_state(session, entitlement, now)
            pending = state["pending"]
            if pending is not None:
                status = f"⏳ Pending payout request #{pending.id}"
            elif state["reason"] == "cooldown":
                status = f"Next claim: {state['next_claim_at']:%d %b %Y, %H:%M} UTC"
            elif state["reason"] == "cap_reached":
                status = "Maximum claim amount reached"
            elif available_funds < entitlement.daily_claim_amount:
                status = "Unavailable: payout pool has insufficient available funds"
            else:
                status = "Eligible to request"
                buttons.append(
                    [
                        InlineKeyboardButton(
                            text=f"Request {money(entitlement.daily_claim_amount)} · {entitlement.plan_name[:18]}",
                            callback_data=f"claimrequest:{entitlement.order_id}",
                        )
                    ]
                )
            lines.append(
                f"👑 {entitlement.plan_name} · {state['remaining_days']} days left\n"
                f"Claim amount: {money(entitlement.daily_claim_amount)} · "
                f"Paid: {money(state['paid_total'])} / {money(entitlement.claim_max_amount)}\n"
                f"{status}"
            )
        if not entitlements:
            await message.answer(
                "💎 No active Daily Claim plan was found. Claims require an eligible VIP purchase."
            )
            return
        lines.append(
            "\nClaims are not guaranteed. Requests reserve only admin-recorded pool funds and remain pending until the actual payout is sent and recorded."
        )
        await message.answer(
            "\n\n".join(lines),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons) if buttons else None,
        )


@router.callback_query(F.data.startswith("claimrequest:"))
async def request_claim_callback(callback: CallbackQuery) -> None:
    try:
        entitlement_order_id = int(callback.data.split(":", 1)[1])
        async with SessionFactory() as session:
            async with session.begin():
                claim, remaining_pool = await request_daily_claim(
                    session, callback.from_user.id, entitlement_order_id
                )
        from bot.handlers.admin import daily_claim_review_keyboard

        await notify_admin(
            callback.bot,
            f"Daily claim #{claim.id} pending payout\n"
            f"User: {claim.user_id}\nAmount: {money(claim.amount)}\n"
            f"Reserved pool remaining: {money(remaining_pool)}\n"
            "Send the payout first; only then mark it paid with the actual reference.",
            daily_claim_review_keyboard(claim.id),
        )
        await callback.message.answer(
            f"⏳ Claim request #{claim.id} submitted for {money(claim.amount)}.\n"
            "Status: Pending payout. No wallet balance was credited. It will show as paid only after an administrator records the actual payout reference."
        )
        await callback.answer("Claim request submitted")
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
    except Exception:
        await callback.answer("Could not submit the claim. Please try again.", show_alert=True)


@router.message(F.text == BTN_PRODUCTS)
async def products(message: Message) -> None:
    async with SessionFactory() as session:
        items = list(
            (
                await session.scalars(
                    select(Product).where(Product.is_active.is_(True)).order_by(Product.id.desc())
                )
            ).all()
        )
        if not items:
            await message.answer(
                "🛍 PRODUCT CATALOGUE\n"
                "━━━━━━━━━━━━━━\n"
                "No products are currently available. Please contact support for assistance."
            )
            return
        buttons = []
        for item in items:
            stock = "In stock" if item.stock_quantity is None else f"Stock: {item.stock_quantity}"
            buttons.append(
                [
                    InlineKeyboardButton(
                        text=f"🛒 {item.name[:18]} · {money(item.price)}",
                        callback_data=f"buyproduct:{item.id}",
                    ),
                    InlineKeyboardButton(text="ℹ️ Details", callback_data=f"productinfo:{item.id}"),
                ]
            )
        summary = "\n".join(
            f"• {item.name[:50]} — {money(item.price)} · "
            f"{'In stock' if item.stock_quantity is None else f'{item.stock_quantity} available'}"
            for item in items[:10]
        )
        await message.answer(
            "🛍 PRODUCTS & SERVICES\n"
            "━━━━━━━━━━━━━━\n"
            f"{summary}\n\n"
            "The displayed price is deducted from your available wallet balance when you purchase.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        )


@router.callback_query(F.data.startswith("productinfo:"))
async def product_info(callback: CallbackQuery) -> None:
    try:
        product_id = int(callback.data.split(":", 1)[1])
    except ValueError:
        await callback.answer("Invalid product.", show_alert=True)
        return
    async with SessionFactory() as session:
        product = await session.get(Product, product_id)
    if product is None or not product.is_active:
        await callback.answer("Product unavailable.", show_alert=True)
        return
    stock = "Available" if product.stock_quantity is None else f"{product.stock_quantity} available"
    await callback.message.answer(
        f"🛍 {product.name}\n"
        "━━━━━━━━━━━━━━\n"
        f"{product.description or 'No description provided.'}\n\n"
        f"💰 Price: {money(product.price)}\n"
        f"📦 {stock}"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("buyproduct:"))
async def buy_product_callback(callback: CallbackQuery) -> None:
    try:
        product_id = int(callback.data.split(":", 1)[1])
        async with SessionFactory() as session:
            async with session.begin():
                order = await buy_product(session, callback.from_user.id, product_id)
        await callback.message.answer(
            "✅ PURCHASE COMPLETE\n"
            "━━━━━━━━━━━━━━\n"
            f"🛍 {order.product_name}\n"
            f"💰 Paid from wallet: {money(order.amount)}\n"
            f"🧾 Order: #{order.id}"
        )
        await callback.answer("Purchased")
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)
    except Exception:
        await callback.answer("Could not complete the purchase. Please try again.", show_alert=True)


@router.message(F.text == BTN_DEPOSIT)
async def deposit_start(message: Message, state: FSMContext) -> None:
    async with SessionFactory() as session:
        upi_id = await get_setting(session, "upi_id")
        qr_file_id = await get_setting(session, "upi_qr_file_id")
    if not upi_id and not qr_file_id:
        await message.answer("💳 Deposits are not configured yet. Please contact support.")
        return
    await state.set_state(DepositFlow.amount)
    await message.answer(
        "💳 UPI DEPOSIT\n"
        "━━━━━━━━━━━━━━\n"
        "1. Pay only to the official UPI details below.\n"
        "2. After completing the transfer, submit the exact amount and bank UTR/reference.\n\n"
        f"📲 UPI ID: {upi_id or 'Scan the official QR below'}\n\n"
        "⚠️ An administrator checks the receiving account. Your balance is credited only after the payment is verified."
    )
    if qr_file_id:
        await message.answer_photo(qr_file_id, caption="📷 Official UPI payment QR")
    await message.answer("After paying, enter the exact amount sent (₹1–₹10,00,000).")


@router.message(DepositFlow.amount)
async def deposit_amount(message: Message, state: FSMContext) -> None:
    try:
        amount = parse_amount(message.text or "")
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await state.update_data(amount=str(amount))
    await state.set_state(DepositFlow.utr)
    await message.answer("Enter the UTR / payment reference shown in your bank app.")


@router.message(DepositFlow.utr)
async def deposit_utr(message: Message, state: FSMContext) -> None:
    utr = (message.text or "").strip()
    if not 4 <= len(utr) <= 64:
        await message.answer("Enter a UTR/reference between 4 and 64 characters.")
        return
    data = await state.get_data()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                deposit = await create_deposit(session, message.from_user.id, Decimal(data["amount"]), utr)
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    from bot.handlers.admin import deposit_review_keyboard

    await notify_admin(
        message.bot,
        f"Deposit #{deposit.id} needs review\nUser: {deposit.user_id}\nAmount: {money(deposit.amount)}\nUTR: {deposit.utr}\n"
        "Verify this transfer against the receiving account before approving.",
        deposit_review_keyboard(deposit.id),
    )
    await message.answer(
        "⏳ DEPOSIT SUBMITTED\n"
        "━━━━━━━━━━━━━━\n"
        f"🧾 Request: #{deposit.id}\n"
        f"💰 Amount: {money(deposit.amount)}\n"
        f"🔎 UTR: {deposit.utr}\n"
        "📍 Status: Pending verification\n\n"
        "Processing target: within 24 hours where feasible; this is not a guarantee. Your balance updates only after verification. Track this request in 📜 History or with /status."
    )


@router.message(F.text == BTN_WITHDRAW)
async def withdrawal_start(message: Message, state: FSMContext) -> None:
    async with SessionFactory() as session:
        user = await session.get(User, message.from_user.id)
    if user is None or user.balance < MIN_AMOUNT:
        await message.answer("💸 Your available balance is too low to request a withdrawal.")
        return
    await state.set_state(WithdrawalFlow.amount)
    await message.answer(
        "💸 WITHDRAWAL REQUEST\n"
        "━━━━━━━━━━━━━━\n"
        f"Available balance: {money(user.balance)}\n"
        "Enter the amount you want to withdraw (₹1–₹10,00,000). The amount will be reserved while your request is reviewed."
    )


@router.message(WithdrawalFlow.amount)
async def withdrawal_amount(message: Message, state: FSMContext) -> None:
    try:
        amount = parse_amount(message.text or "")
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await state.update_data(amount=str(amount))
    await state.set_state(WithdrawalFlow.upi_id)
    await message.answer("Enter the UPI ID where you want to receive payment (example: name@bank).")


@router.message(WithdrawalFlow.upi_id)
async def withdrawal_upi(message: Message, state: FSMContext) -> None:
    upi_id = (message.text or "").strip()
    if not is_valid_upi_id(upi_id):
        await message.answer("Enter a valid UPI ID, such as name@bank.")
        return
    data = await state.get_data()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                request = await request_withdrawal(
                    session, message.from_user.id, Decimal(data["amount"]), upi_id
                )
    except ValueError as exc:
        await message.answer(str(exc))
        return
    await state.clear()
    from bot.handlers.admin import withdrawal_review_keyboard

    await notify_admin(
        message.bot,
        f"Withdrawal #{request.id} needs review\nUser: {request.user_id}\nAmount: {money(request.amount)}\n"
        f"UPI ID: {request.upi_id}\nStatus: pending review (amount reserved).",
        withdrawal_review_keyboard(request.id),
    )
    await message.answer(
        "⏳ WITHDRAWAL SUBMITTED\n"
        "━━━━━━━━━━━━━━\n"
        f"🧾 Request: #{request.id}\n"
        f"💰 Amount: {money(request.amount)}\n"
        f"📍 Status: Pending review · amount reserved\n\n"
        "Processing target: within 24 hours where feasible; this is not a guarantee. An administrator sends the payment and updates its status. Track updates in 📜 History or with /status."
    )


@router.message(F.text == BTN_HISTORY)
async def transaction_history(message: Message) -> None:
    async with SessionFactory() as session:
        entries = list(
            (
                await session.scalars(
                    select(WalletEntry)
                    .where(WalletEntry.user_id == message.from_user.id)
                    .order_by(desc(WalletEntry.created_at))
                    .limit(10)
                )
            ).all()
        )
        deposits = list((await session.scalars(select(Deposit).where(Deposit.user_id == message.from_user.id).order_by(desc(Deposit.created_at)).limit(5))).all())
        withdrawals = list((await session.scalars(select(Withdrawal).where(Withdrawal.user_id == message.from_user.id).order_by(desc(Withdrawal.created_at)).limit(5))).all())
        claims = list(
            (
                await session.scalars(
                    select(DailyClaim)
                    .where(DailyClaim.user_id == message.from_user.id)
                    .order_by(desc(DailyClaim.requested_at))
                    .limit(10)
                )
            ).all()
        )
    if not entries and not deposits and not withdrawals and not claims:
        await message.answer(
            "📜 TRANSACTION HISTORY\n"
            "━━━━━━━━━━━━━━\n"
            "No transactions yet. Verified deposits, withdrawals, referral credits, and membership purchases will appear here."
        )
        return
    lines = ["📜 TRANSACTION HISTORY", "━━━━━━━━━━━━━━", "💰 WALLET ACTIVITY"]
    for entry in entries:
        sign = "+" if entry.amount > 0 else ""
        label = WALLET_ENTRY_LABELS.get(entry.kind, entry.kind.replace("_", " ").title())
        lines.append(
            f"{'➕' if entry.amount > 0 else '➖'} {label}\n"
            f"   {sign}{money(entry.amount)} · {entry.created_at:%d %b %Y, %H:%M} UTC\n"
            f"   {entry.note[:100]}"
        )
    if deposits:
        lines.append("\n💳 DEPOSIT REQUESTS")
        lines.extend(
            f"#{item.id} · {money(item.amount)}\n"
            f"   {DEPOSIT_STATUS.get(item.status, item.status.title())} · {item.created_at:%d %b %Y, %H:%M} UTC\n"
            f"   UTR: {item.utr}"
            + (f"\n   Note: {item.rejection_reason}" if item.rejection_reason else "")
            for item in deposits
        )
    if withdrawals:
        lines.append("\n💸 WITHDRAWAL REQUESTS")
        lines.extend(
            f"#{item.id} · {money(item.amount)}\n"
            f"   {WITHDRAWAL_STATUS.get(item.status, item.status.title())} · {item.created_at:%d %b %Y, %H:%M} UTC"
            + (f"\n   Payment ref: {item.payment_reference}" if item.payment_reference else "")
            + (f"\n   Note: {item.rejection_reason}" if item.rejection_reason else "")
            for item in withdrawals
        )
    if claims:
        lines.append("\n💎 DAILY CLAIM REQUESTS")
        lines.extend(
            f"#{item.id} · {money(item.amount)}\n"
            f"   {CLAIM_STATUS.get(item.status, item.status.title())} · "
            f"{item.requested_at:%d %b %Y, %H:%M} UTC"
            + (f"\n   Paid at: {item.paid_at:%d %b %Y, %H:%M} UTC" if item.paid_at else "")
            + (f"\n   Payout ref: {item.payout_reference}" if item.payout_reference else "")
            + (f"\n   Note: {item.rejection_reason}" if item.rejection_reason else "")
            for item in claims
        )
    await message.answer("\n".join(lines))


@router.message(F.text == BTN_REFERRAL)
async def referral(message: Message) -> None:
    async with SessionFactory() as session:
        user = await session.get(User, message.from_user.id)
        percent = await get_setting(session, "referral_commission_percent", "20")
        bot_info = await message.bot.get_me()
    if user is None:
        await message.answer("Send /start to create your account.")
        return
    await message.answer(
        "🤝 REFERRAL PROGRAM\n"
        "━━━━━━━━━━━━━━\n"
        f"Your invite link:\nhttps://t.me/{bot_info.username}?start={user.telegram_id}\n\n"
        f"🎁 Commission: {percent}% of a referred user's deposit, credited only after the deposit is verified.\n"
        "Unverified payments do not earn commission."
    )


@router.message(F.text == BTN_SUPPORT)
async def support(message: Message) -> None:
    async with SessionFactory() as session:
        details = await get_setting(session, "support_details", "Support details have not been configured.")
    await message.answer(f"🆘 SUPPORT\n━━━━━━━━━━━━━━\n{details}")


@router.message(Command("status"))
async def status(message: Message) -> None:
    async with SessionFactory() as session:
        deposits = list((await session.scalars(select(Deposit).where(Deposit.user_id == message.from_user.id).order_by(desc(Deposit.created_at)).limit(5))).all())
        withdrawals = list((await session.scalars(select(Withdrawal).where(Withdrawal.user_id == message.from_user.id).order_by(desc(Withdrawal.created_at)).limit(5))).all())
    lines = ["📍 REQUEST STATUS", "━━━━━━━━━━━━━━"]
    lines.extend(
        f"💳 Deposit #{d.id} · {money(d.amount)}\n"
        f"   {DEPOSIT_STATUS.get(d.status, d.status.title())}"
        + (f"\n   Note: {d.rejection_reason}" if d.rejection_reason else "")
        for d in deposits
    )
    lines.extend(
        f"💸 Withdrawal #{w.id} · {money(w.amount)}\n"
        f"   {WITHDRAWAL_STATUS.get(w.status, w.status.title())}"
        + (f" — {w.rejection_reason}" if w.rejection_reason else "")
        + (f"\n   Payment ref: {w.payment_reference}" if w.payment_reference else "")
        for w in withdrawals
    )
    await message.answer("\n\n".join(lines) if len(lines) > 2 else "No deposit or withdrawal requests found.")
