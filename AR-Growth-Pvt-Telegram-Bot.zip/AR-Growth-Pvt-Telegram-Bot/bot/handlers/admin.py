from datetime import timedelta
from decimal import Decimal, InvalidOperation

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import desc, func, select

from bot.config import get_settings
from bot.db import SessionFactory
from bot.keyboards import BTN_ADMIN, admin_menu, back_to_admin
from bot.models import (
    AdminActivity,
    ClaimFunding,
    ClaimPool,
    DailyClaim,
    Deposit,
    Product,
    Setting,
    User,
    VIPEntitlement,
    VIPPlan,
    WalletEntry,
    Withdrawal,
)
from bot.services import (
    add_claim_pool_funding,
    mark_daily_claim_paid,
    get_setting,
    record_admin,
    reject_daily_claim,
    review_deposit,
    review_withdrawal,
    mark_withdrawal_paid,
    set_setting,
    utcnow,
)
from bot.states import (
    AdminRejectFlow,
    ClaimFundingFlow,
    ClaimRuleFlow,
    PaidFlow,
    PlanFlow,
    ProductFlow,
    SettingFlow,
)

router = Router()


def is_admin(telegram_id: int) -> bool:
    return telegram_id == get_settings().admin_telegram_id


def money(amount: Decimal) -> str:
    return f"₹{amount:,.2f}"


def deposit_review_keyboard(deposit_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Verified · approve", callback_data=f"reviewdep:approve:{deposit_id}"),
                InlineKeyboardButton(text="❌ Reject", callback_data=f"reviewdep:reject:{deposit_id}"),
            ]
        ]
    )


def withdrawal_review_keyboard(withdrawal_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Approve payout", callback_data=f"reviewwd:approve:{withdrawal_id}"),
                InlineKeyboardButton(text="↩️ Reject / refund", callback_data=f"reviewwd:reject:{withdrawal_id}"),
            ]
        ]
    )


def daily_claim_review_keyboard(claim_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Mark Paid After Transfer",
                    callback_data=f"dailyclaim:paid:{claim_id}",
                ),
                InlineKeyboardButton(
                    text="❌ Reject & Release Funds",
                    callback_data=f"dailyclaim:reject:{claim_id}",
                ),
            ]
        ]
    )


def admin_only(telegram_id: int) -> bool:
    return is_admin(telegram_id)


@router.message(Command("admin"))
@router.message(F.text == BTN_ADMIN)
async def open_admin(message: Message, state: FSMContext) -> None:
    await state.clear()
    if not admin_only(message.from_user.id):
        await message.answer("This panel is restricted.")
        return
    await message.answer("🛡 AR Growth Pvt. — Admin Panel", reply_markup=admin_menu())


@router.callback_query(F.data.startswith("admin:"))
async def admin_navigation(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    action = callback.data.split(":", 1)[1]
    async with SessionFactory() as session:
        if action == "home":
            await callback.message.answer("🛡 AR Growth Pvt. — Admin Panel", reply_markup=admin_menu())
        elif action == "deposits":
            rows = list((await session.scalars(select(Deposit).where(Deposit.status == "pending").order_by(Deposit.created_at).limit(25))).all())
            if not rows:
                await callback.message.answer("No pending deposits.", reply_markup=back_to_admin())
            for row in rows:
                await callback.message.answer(
                    f"Deposit #{row.id}\nUser: {row.user_id}\nAmount: {money(row.amount)}\nUTR: {row.utr}\n"
                    f"Submitted: {row.created_at:%d %b %Y %H:%M} UTC\nVerify the receiving account before approval.",
                    reply_markup=deposit_review_keyboard(row.id),
                )
        elif action == "withdrawals":
            pending = list((await session.scalars(select(Withdrawal).where(Withdrawal.status == "pending").order_by(Withdrawal.created_at).limit(25))).all())
            approved = list((await session.scalars(select(Withdrawal).where(Withdrawal.status == "approved").order_by(Withdrawal.created_at).limit(25))).all())
            if not pending and not approved:
                await callback.message.answer("No pending or approved withdrawals.", reply_markup=back_to_admin())
            for row in pending:
                await callback.message.answer(
                    f"Withdrawal #{row.id}\nUser: {row.user_id}\nAmount: {money(row.amount)}\nUPI: {row.upi_id}\n"
                    f"Submitted: {row.created_at:%d %b %Y %H:%M} UTC\nAmount is reserved.",
                    reply_markup=withdrawal_review_keyboard(row.id),
                )
            for row in approved:
                await callback.message.answer(
                    f"Approved withdrawal #{row.id}\nUser: {row.user_id}\nAmount: {money(row.amount)}\nUPI: {row.upi_id}\n"
                    "After you send the UPI payment, mark it paid and enter its reference.",
                    reply_markup=InlineKeyboardMarkup(
                        inline_keyboard=[[InlineKeyboardButton(text="Mark paid", callback_data=f"reviewwd:paid:{row.id}")]]
                    ),
                )
        elif action == "plans":
            rows = list((await session.scalars(select(VIPPlan).order_by(VIPPlan.sort_order))).all())
            buttons = [
                [InlineKeyboardButton(text=f"{p.sort_order}. {p.name} · {money(p.price)} · {'active' if p.is_active else 'off'}", callback_data=f"plan:{p.id}")]
                for p in rows
            ]
            await callback.message.answer(
                "Select a plan to edit its name, price, duration, and claim rules. Claim-rule edits apply to new purchases only.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons + [[InlineKeyboardButton(text="⬅️ Admin Panel", callback_data="admin:home")]]),
            )
        elif action == "products":
            rows = list((await session.scalars(select(Product).order_by(Product.id.desc()).limit(50))).all())
            buttons = [
                [InlineKeyboardButton(text=f"{p.name} · {money(p.price)} · {'active' if p.is_active else 'deleted'}", callback_data=f"product:{p.id}")]
                for p in rows
            ]
            buttons.append([InlineKeyboardButton(text="➕ Add product / service", callback_data="product:add")])
            buttons.append([InlineKeyboardButton(text="⬅️ Admin Panel", callback_data="admin:home")])
            await callback.message.answer(
                "🛍 PRODUCT CATALOGUE\n"
                "Add or edit real products and services. The customer menu currently focuses on VIP plans.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
            )
        elif action == "settings":
            async with session.begin():
                upi = await get_setting(session, "upi_id")
                commission = await get_setting(session, "referral_commission_percent", "20")
                support = await get_setting(session, "support_details")
                qr = await get_setting(session, "upi_qr_file_id")
            await callback.message.answer(
                f"📲 UPI ID: {upi or '(not set)'}\n📷 QR code: {'set' if qr else 'not set'}\n"
                f"🤝 Referral commission: {commission}%\n🆘 Support: {support or '(not set)'}",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="📲 Edit UPI ID", callback_data="setting:upi")],
                        [InlineKeyboardButton(text="📷 Upload / Replace QR", callback_data="setting:qr")],
                        [InlineKeyboardButton(text="🤝 Edit Referral Commission", callback_data="setting:referral")],
                        [InlineKeyboardButton(text="🆘 Edit Support Details", callback_data="setting:support")],
                        [InlineKeyboardButton(text="⬅️ Admin Panel", callback_data="admin:home")],
                    ]
                ),
            )
        elif action == "claims":
            pool = await session.get(ClaimPool, 1)
            available = pool.available_funds if pool else Decimal("0.00")
            funded_total = await session.scalar(
                select(func.coalesce(func.sum(ClaimFunding.amount), 0))
            ) or 0
            reserved = await session.scalar(
                select(func.coalesce(func.sum(DailyClaim.amount), 0)).where(
                    DailyClaim.status == "pending"
                )
            ) or 0
            paid_total = await session.scalar(
                select(func.coalesce(func.sum(DailyClaim.amount), 0)).where(
                    DailyClaim.status == "paid"
                )
            ) or 0
            pending_count = await session.scalar(
                select(func.count()).select_from(DailyClaim).where(DailyClaim.status == "pending")
            ) or 0
            await callback.message.answer(
                "💎 DAILY CLAIMS & PAYOUT FUNDS\n"
                "━━━━━━━━━━━━━━\n"
                f"Admin-recorded verified funding: {money(Decimal(funded_total))}\n"
                f"Available for new claims: {money(available)}\n"
                f"Reserved for pending claims: {money(Decimal(reserved))}\n"
                f"Paid claims recorded: {money(Decimal(paid_total))}\n"
                f"Pending payout requests: {pending_count}\n\n"
                "Only add money after confirming cleared funds in the real payout account. Mark claims paid only after sending the actual payout.",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="➕ Record Verified Funds", callback_data="claimfund:add")],
                        [InlineKeyboardButton(text="⏳ Pending Claim Requests", callback_data="dailyclaims:list")],
                        [InlineKeyboardButton(text="⚙️ Edit Claim Rules", callback_data="claimrules:list")],
                        [InlineKeyboardButton(text="⬅️ Admin Panel", callback_data="admin:home")],
                    ]
                ),
            )
        elif action == "reports":
            now = utcnow()
            month_ago = now - timedelta(days=30)
            user_count = await session.scalar(select(func.count()).select_from(User)) or 0
            approved_deposits = await session.scalar(
                select(func.coalesce(func.sum(Deposit.amount), 0)).where(
                    Deposit.status == "approved", Deposit.reviewed_at >= month_ago
                )
            )
            paid_withdrawals = await session.scalar(
                select(func.coalesce(func.sum(Withdrawal.amount), 0)).where(
                    Withdrawal.status == "paid", Withdrawal.paid_at >= month_ago
                )
            )
            pending_deposits = await session.scalar(select(func.count()).select_from(Deposit).where(Deposit.status == "pending")) or 0
            pending_withdrawals = await session.scalar(select(func.count()).select_from(Withdrawal).where(Withdrawal.status.in_(["pending", "approved"]))) or 0
            await callback.message.answer(
                f"📊 REPORT · LAST 30 DAYS\n"
                f"✅ Verified deposits: {money(Decimal(approved_deposits))}\n"
                f"💸 Paid withdrawals: {money(Decimal(paid_withdrawals))}\n"
                f"👤 Total accounts: {user_count}\n"
                f"⏳ Pending deposits: {pending_deposits}\n"
                f"💸 Withdrawals pending review/payment: {pending_withdrawals}",
                reply_markup=back_to_admin(),
            )
        elif action == "logs":
            rows = list((await session.scalars(select(AdminActivity).order_by(desc(AdminActivity.created_at)).limit(20))).all())
            text = "\n".join(
                f"{row.created_at:%d %b %H:%M} UTC · {row.admin_id} · {row.action} · {row.details}"
                for row in rows
            ) or "No admin activity recorded."
            await callback.message.answer(text, reply_markup=back_to_admin())
        else:
            await callback.answer("Unknown admin action.")
            return
    await callback.answer()


@router.callback_query(F.data == "claimfund:add")
async def claim_funding_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    await state.set_state(ClaimFundingFlow.amount)
    await callback.message.answer(
        "Enter the amount of cleared funds actually available for claim payouts. "
        "Do not count pending deposits or expected income."
    )
    await callback.answer()


@router.message(ClaimFundingFlow.amount)
async def claim_funding_amount(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    try:
        amount = Decimal((message.text or "").strip())
        if not amount.is_finite() or amount <= 0 or amount > Decimal("100000000"):
            raise ValueError("Enter an amount greater than ₹0 and at most ₹10,00,00,000.")
    except (InvalidOperation, ValueError) as exc:
        await message.answer(str(exc) or "Enter a valid amount.")
        return
    await state.update_data(amount=str(amount))
    await state.set_state(ClaimFundingFlow.reference)
    await message.answer(
        "Enter the actual bank/reference for these funds. The reference must be unique. "
        "Only continue after verifying that the money has cleared."
    )


@router.message(ClaimFundingFlow.reference)
async def claim_funding_reference(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    reference = (message.text or "").strip()
    if not 1 <= len(reference) <= 128:
        await message.answer("Enter a funding reference between 1 and 128 characters.")
        return
    try:
        async with SessionFactory() as session:
            async with session.begin():
                funding, balance = await add_claim_pool_funding(
                    session, message.from_user.id, Decimal(data["amount"]), reference
                )
                await record_admin(
                    session,
                    message.from_user.id,
                    "claim_pool_funded",
                    f"funding_id={funding.id}; amount={funding.amount}; reference={reference}",
                )
        await message.answer(
            f"✅ Verified funds recorded: {money(funding.amount)}\n"
            f"Available for new claims: {money(balance)}"
        )
        await state.clear()
    except ValueError as exc:
        await message.answer(str(exc))


@router.callback_query(F.data == "dailyclaims:list")
async def pending_daily_claims(callback: CallbackQuery) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    async with SessionFactory() as session:
        claims = list(
            (
                await session.scalars(
                    select(DailyClaim)
                    .where(DailyClaim.status == "pending")
                    .order_by(DailyClaim.requested_at)
                    .limit(50)
                )
            ).all()
        )
        if not claims:
            await callback.message.answer(
                "No pending daily-claim requests.",
                reply_markup=back_to_admin(),
            )
        for claim in claims:
            entitlement = await session.get(VIPEntitlement, claim.entitlement_order_id)
            plan_name = entitlement.plan_name if entitlement else "VIP Plan"
            await callback.message.answer(
                f"💎 Daily Claim #{claim.id}\n"
                f"User: {claim.user_id}\nPlan: {plan_name}\n"
                f"Amount: {money(claim.amount)}\n"
                f"Requested: {claim.requested_at:%d %b %Y, %H:%M} UTC\n"
                "Send the actual payout before marking this request paid.",
                reply_markup=daily_claim_review_keyboard(claim.id),
            )
    await callback.answer()


@router.callback_query(F.data == "claimrules:list")
async def claim_rules_list(callback: CallbackQuery) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    async with SessionFactory() as session:
        plans = list((await session.scalars(select(VIPPlan).order_by(VIPPlan.sort_order))).all())
    buttons = [
        [
            InlineKeyboardButton(
                text=f"{plan.name} · {money(plan.daily_claim_amount)}/day · cap {money(plan.claim_max_amount)}",
                callback_data=f"claimrule:{plan.id}",
            )
        ]
        for plan in plans
    ]
    buttons.append([InlineKeyboardButton(text="⬅️ Claims & Funds", callback_data="admin:claims")])
    await callback.message.answer(
        "💎 CLAIM RULES\n"
        "Rules are copied into new purchases. Existing entitlements keep their original terms.\n"
        "Plan duration is edited from VIP Plans.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("claimrule:"))
async def claim_rule_details(callback: CallbackQuery) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    plan_id = int(callback.data.split(":", 1)[1])
    async with SessionFactory() as session:
        plan = await session.get(VIPPlan, plan_id)
    if plan is None:
        await callback.answer("Plan not found.", show_alert=True)
        return
    await callback.message.answer(
        f"💎 {plan.name}\n"
        f"Daily claim amount: {money(plan.daily_claim_amount)}\n"
        f"Claim interval: {plan.claim_interval_hours} hours\n"
        f"Maximum claim total: {money(plan.claim_max_amount)}\n"
        f"Duration: {plan.duration_days} days\n\n"
        "Rules apply to new purchases only; existing user entitlements are unchanged.",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="💰 Edit Daily Amount", callback_data=f"claimedit:amount:{plan.id}")],
                [InlineKeyboardButton(text="⏱ Edit Interval", callback_data=f"claimedit:interval:{plan.id}")],
                [InlineKeyboardButton(text="🧮 Edit Maximum Total", callback_data=f"claimedit:cap:{plan.id}")],
                [InlineKeyboardButton(text="⬅️ Claim Rules", callback_data="claimrules:list")],
            ]
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("claimedit:"))
async def claim_rule_edit_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    _, field, raw_plan_id = callback.data.split(":")
    if field not in {"amount", "interval", "cap"}:
        await callback.answer("Unknown claim rule.", show_alert=True)
        return
    await state.set_state(ClaimRuleFlow.value)
    await state.update_data(plan_id=int(raw_plan_id), field=field)
    prompts = {
        "amount": "Send daily claim amount in INR (0 disables claims). Set the maximum total first.",
        "interval": "Send the interval in whole hours (1–720).",
        "cap": "Send the maximum total claim amount in INR (0 disables claims).",
    }
    await callback.message.answer(prompts[field])
    await callback.answer()


@router.message(ClaimRuleFlow.value)
async def claim_rule_edit_value(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    raw_value = (message.text or "").strip()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                plan = await session.get(VIPPlan, data["plan_id"], with_for_update=True)
                if plan is None:
                    raise ValueError("Plan not found.")
                if data["field"] == "interval":
                    value = int(raw_value)
                    if not 1 <= value <= 720:
                        raise ValueError("Interval must be between 1 and 720 hours.")
                    plan.claim_interval_hours = value
                else:
                    value = Decimal(raw_value)
                    if not value.is_finite() or not 0 <= value <= Decimal("10000000"):
                        raise ValueError("Claim amount must be between ₹0 and ₹1,00,00,000.")
                    value = value.quantize(Decimal("0.01"))
                    if data["field"] == "amount":
                        if value > 0 and plan.claim_max_amount < value:
                            raise ValueError("Set the maximum total to at least the daily amount first.")
                        plan.daily_claim_amount = value
                    else:
                        if value > 0 and plan.daily_claim_amount > value:
                            raise ValueError("Maximum total cannot be below the daily claim amount.")
                        plan.claim_max_amount = value
                await record_admin(
                    session,
                    message.from_user.id,
                    "vip_claim_rule_edited",
                    f"plan_id={plan.id}; field={data['field']}; value={raw_value}",
                )
        await message.answer("Claim rule updated for future purchases.")
        await state.clear()
    except (ValueError, InvalidOperation) as exc:
        await message.answer(str(exc))


@router.callback_query(F.data.startswith("dailyclaim:"))
async def daily_claim_admin_action(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    _, action, raw_claim_id = callback.data.split(":")
    claim_id = int(raw_claim_id)
    if action == "reject":
        await state.set_state(AdminRejectFlow.reason)
        await state.update_data(request_type="daily_claim", request_id=claim_id)
        await callback.message.answer(
            f"Enter a rejection reason for daily claim #{claim_id}. Reserved funds will return to the pool."
        )
        await callback.answer()
        return
    if action == "paid":
        await state.set_state(PaidFlow.reference)
        await state.update_data(request_type="daily_claim", claim_id=claim_id)
        await callback.message.answer(
            f"After sending the actual payout for daily claim #{claim_id}, enter its bank/UPI reference."
        )
        await callback.answer()
        return
    await callback.answer("Unknown claim action.", show_alert=True)


@router.callback_query(F.data.startswith("reviewdep:"))
async def review_deposit_callback(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    _, action, raw_id = callback.data.split(":")
    deposit_id = int(raw_id)
    if action == "reject":
        await state.set_state(AdminRejectFlow.reason)
        await state.update_data(request_type="deposit", request_id=deposit_id)
        await callback.message.answer(f"Enter the reason to reject deposit #{deposit_id}. The user will see it.")
        await callback.answer()
        return
    try:
        async with SessionFactory() as session:
            async with session.begin():
                deposit, referrer_id, commission = await review_deposit(
                    session, deposit_id, callback.from_user.id, True
                )
                await record_admin(session, callback.from_user.id, "deposit_approved", f"deposit_id={deposit.id}; user_id={deposit.user_id}; amount={deposit.amount}")
        await callback.bot.send_message(
            deposit.user_id,
            f"Deposit #{deposit.id} approved after verification. {money(deposit.amount)} has been credited to your balance.",
        )
        if referrer_id and commission:
            await callback.bot.send_message(
                referrer_id,
                f"Referral commission credited: {money(commission)} for a verified referral deposit.",
            )
        await callback.message.answer(f"Deposit #{deposit.id} approved and credited.")
        await callback.answer("Approved")
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)


@router.callback_query(F.data.startswith("reviewwd:"))
async def review_withdrawal_callback(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    _, action, raw_id = callback.data.split(":")
    withdrawal_id = int(raw_id)
    if action == "reject":
        await state.set_state(AdminRejectFlow.reason)
        await state.update_data(request_type="withdrawal", request_id=withdrawal_id)
        await callback.message.answer(
            f"Enter the reason to reject withdrawal #{withdrawal_id}. The reserved balance will be refunded."
        )
        await callback.answer()
        return
    if action == "paid":
        await state.set_state(PaidFlow.reference)
        await state.update_data(withdrawal_id=withdrawal_id)
        await callback.message.answer(
            f"After confirming the UPI transfer for withdrawal #{withdrawal_id}, enter the payment reference."
        )
        await callback.answer()
        return
    try:
        async with SessionFactory() as session:
            async with session.begin():
                request = await review_withdrawal(session, withdrawal_id, callback.from_user.id, "approve")
                await record_admin(session, callback.from_user.id, "withdrawal_approved", f"withdrawal_id={request.id}; user_id={request.user_id}; amount={request.amount}")
        await callback.bot.send_message(
            request.user_id,
            f"Withdrawal #{request.id} approved for payout. Status: awaiting payment. The request is not marked paid yet.",
        )
        await callback.message.answer(
            f"Withdrawal #{request.id} approved for payout. Mark it paid only after sending the money.",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="Mark paid", callback_data=f"reviewwd:paid:{request.id}")]]
            ),
        )
        await callback.answer("Approved for payout")
    except ValueError as exc:
        await callback.answer(str(exc), show_alert=True)


@router.message(AdminRejectFlow.reason)
async def reject_reason(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    reason = (message.text or "").strip()
    if len(reason) < 3:
        await message.answer("Provide a short reason (at least 3 characters).")
        return
    data = await state.get_data()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                if data["request_type"] == "deposit":
                    request, _, _ = await review_deposit(
                        session, data["request_id"], message.from_user.id, False, reason
                    )
                    action = "deposit_rejected"
                elif data["request_type"] == "withdrawal":
                    request = await review_withdrawal(
                        session, data["request_id"], message.from_user.id, "reject", reason
                    )
                    action = "withdrawal_rejected_refunded"
                else:
                    request = await reject_daily_claim(
                        session, data["request_id"], message.from_user.id, reason
                    )
                    action = "daily_claim_rejected_funds_released"
                await record_admin(session, message.from_user.id, action, f"request_id={request.id}; reason={reason}")
        user_id = request.user_id
        amount = request.amount
        kind = data["request_type"]
        if kind == "daily_claim":
            await message.bot.send_message(
                user_id,
                f"Daily claim #{request.id} was rejected. Reserved {money(amount)} was released back to the payout pool. Reason: {reason}",
            )
            await message.answer(f"Daily claim #{request.id} rejected and funds released.")
            await state.clear()
            return
        await message.bot.send_message(
            user_id,
            f"{kind.title()} #{request.id} was rejected. Reason: {reason}"
            + (f" The reserved {money(amount)} was returned to your balance." if kind == "withdrawal" else ""),
        )
        await message.answer(f"{kind.title()} #{request.id} rejected.")
        await state.clear()
    except ValueError as exc:
        await message.answer(str(exc))


@router.message(PaidFlow.reference)
async def paid_reference(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    reference = (message.text or "").strip()
    if not 3 <= len(reference) <= 128:
        await message.answer("Enter a payment reference between 3 and 128 characters.")
        return
    data = await state.get_data()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                if data.get("request_type") == "daily_claim":
                    request = await mark_daily_claim_paid(
                        session, data["claim_id"], message.from_user.id, reference
                    )
                    action = "daily_claim_marked_paid"
                    details = f"claim_id={request.id}; user_id={request.user_id}; reference={reference}"
                else:
                    request = await mark_withdrawal_paid(
                        session, data["withdrawal_id"], message.from_user.id, reference
                    )
                    action = "withdrawal_marked_paid"
                    details = f"withdrawal_id={request.id}; reference={reference}"
                await record_admin(session, message.from_user.id, action, details)
        await message.bot.send_message(
            request.user_id,
            (
                f"Daily claim #{request.id} is marked paid after payout confirmation. "
                f"Amount: {money(request.amount)} · Reference: {reference}."
                if data.get("request_type") == "daily_claim"
                else f"Withdrawal #{request.id} is marked paid. Payment reference: {reference}."
            ),
        )
        await message.answer(
            f"Daily claim #{request.id} marked paid."
            if data.get("request_type") == "daily_claim"
            else f"Withdrawal #{request.id} marked paid."
        )
        await state.clear()
    except ValueError as exc:
        await message.answer(str(exc))


@router.callback_query(F.data.startswith("plan:"))
async def plan_details(callback: CallbackQuery) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    plan_id = int(callback.data.split(":", 1)[1])
    async with SessionFactory() as session:
        plan = await session.get(VIPPlan, plan_id)
    if plan is None:
        await callback.answer("Plan not found.", show_alert=True)
        return
    await callback.message.answer(
        f"{plan.name}\nPrice: {money(plan.price)}\nDuration: {plan.duration_days} days\n"
        f"Daily claim: {money(plan.daily_claim_amount)} per {plan.claim_interval_hours} hours\n"
        f"Maximum claim total: {money(plan.claim_max_amount)}",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="✏️ Edit Name", callback_data=f"planedit:name:{plan.id}")],
                [InlineKeyboardButton(text="💰 Edit Price", callback_data=f"planedit:price:{plan.id}")],
                [InlineKeyboardButton(text="📅 Edit Duration", callback_data=f"planedit:duration:{plan.id}")],
                [InlineKeyboardButton(text="💎 Edit Claim Rules", callback_data=f"claimrule:{plan.id}")],
                [InlineKeyboardButton(text="⬅️ All VIP Plans", callback_data="admin:plans")],
            ]
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("planedit:"))
async def plan_edit_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    _, field, raw_id = callback.data.split(":")
    plan_id = int(raw_id)
    await state.set_state(PlanFlow.edit_value)
    await state.update_data(plan_id=plan_id, field=field)
    await callback.message.answer({"name": "Send the new plan name.", "price": "Send the new price in INR.", "duration": "Send the duration in whole days (1–3650)."}[field])
    await callback.answer()


@router.message(PlanFlow.edit_value)
async def plan_edit_value(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    value = (message.text or "").strip()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                plan = await session.get(VIPPlan, data["plan_id"], with_for_update=True)
                if plan is None:
                    raise ValueError("Plan not found.")
                if data["field"] == "name":
                    if not 1 <= len(value) <= 80:
                        raise ValueError("Plan name must be 1–80 characters.")
                    plan.name = value
                elif data["field"] == "price":
                    amount = Decimal(value)
                    if not amount.is_finite() or amount < 0 or amount > Decimal("10000000"):
                        raise ValueError("Price must be between ₹0 and ₹1,00,00,000.")
                    plan.price = amount.quantize(Decimal("0.01"))
                else:
                    days = int(value)
                    if not 1 <= days <= 3650:
                        raise ValueError("Duration must be 1–3650 days.")
                    plan.duration_days = days
                await record_admin(session, message.from_user.id, "vip_plan_edited", f"plan_id={plan.id}; field={data['field']}; value={value}")
        await message.answer("VIP plan updated.")
        await state.clear()
    except (ValueError, InvalidOperation) as exc:
        await message.answer(str(exc))


@router.callback_query(F.data == "product:add")
async def product_add_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    await state.set_state(ProductFlow.name)
    await state.update_data(product_action="add")
    await callback.message.answer("Send the name of the real product or service.")
    await callback.answer()


@router.callback_query(F.data.startswith("product:"))
async def product_details(callback: CallbackQuery) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    product_id = int(callback.data.split(":", 1)[1])
    async with SessionFactory() as session:
        product = await session.get(Product, product_id)
    if product is None:
        await callback.answer("Product not found.", show_alert=True)
        return
    await callback.message.answer(
        f"{product.name}\n{product.description or '(no description)'}\nPrice: {money(product.price)}\n"
        f"Stock: {'unlimited' if product.stock_quantity is None else product.stock_quantity}\n"
        f"Status: {'active' if product.is_active else 'deleted'}",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="✏️ Edit Name", callback_data=f"productedit:name:{product.id}")],
                [InlineKeyboardButton(text="📝 Edit Description", callback_data=f"productedit:description:{product.id}")],
                [InlineKeyboardButton(text="💰 Edit Price", callback_data=f"productedit:price:{product.id}")],
                [InlineKeyboardButton(text="📦 Edit Stock", callback_data=f"productedit:stock:{product.id}")],
                [InlineKeyboardButton(text="🗑 Delete / Restore", callback_data=f"productdelete:{product.id}")],
                [InlineKeyboardButton(text="⬅️ Products", callback_data="admin:products")],
            ]
        ),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("productedit:"))
async def product_edit_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    _, field, raw_id = callback.data.split(":")
    await state.set_state(ProductFlow.edit_value)
    await state.update_data(product_id=int(raw_id), field=field)
    prompts = {
        "name": "Send the new product/service name.",
        "description": "Send the new description, or /clear to remove it.",
        "price": "Send the new price in INR.",
        "stock": "Send a non-negative stock count or 'unlimited'.",
    }
    await callback.message.answer(prompts[field])
    await callback.answer()


@router.callback_query(F.data.startswith("productdelete:"))
async def product_delete(callback: CallbackQuery) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    product_id = int(callback.data.split(":", 1)[1])
    async with SessionFactory() as session:
        async with session.begin():
            product = await session.get(Product, product_id, with_for_update=True)
            if product is None:
                await callback.answer("Product not found.", show_alert=True)
                return
            product.is_active = not product.is_active
            await record_admin(
                session,
                callback.from_user.id,
                "product_restored" if product.is_active else "product_deleted",
                f"product_id={product.id}; name={product.name}",
            )
            active = product.is_active
    await callback.message.answer(f"Product {'restored' if active else 'removed from the catalogue'}. Past orders remain in history.")
    await callback.answer()


@router.message(ProductFlow.name)
async def product_name(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    name = (message.text or "").strip()
    if not 1 <= len(name) <= 120:
        await message.answer("Name must be 1–120 characters.")
        return
    await state.update_data(name=name)
    await state.set_state(ProductFlow.description)
    await message.answer("Send a truthful product/service description. Do not claim guaranteed earnings.")


@router.message(ProductFlow.description)
async def product_description(message: Message, state: FSMContext) -> None:
    description = (message.text or "").strip()
    if len(description) > 2000:
        await message.answer("Description must be 2,000 characters or less.")
        return
    await state.update_data(description=description)
    await state.set_state(ProductFlow.price)
    await message.answer("Send the price in INR.")


@router.message(ProductFlow.price)
async def product_price(message: Message, state: FSMContext) -> None:
    try:
        price = Decimal((message.text or "").strip())
        if not price.is_finite() or price < 0 or price > Decimal("10000000"):
            raise ValueError
    except (InvalidOperation, ValueError):
        await message.answer("Enter a valid price between ₹0 and ₹1,00,00,000.")
        return
    await state.update_data(price=str(price.quantize(Decimal("0.01"))))
    await state.set_state(ProductFlow.stock)
    await message.answer("Enter stock quantity (0 or higher), or send 'unlimited'.")


@router.message(ProductFlow.stock)
async def product_stock(message: Message, state: FSMContext) -> None:
    value = (message.text or "").strip().lower()
    if value == "unlimited":
        stock = None
    else:
        try:
            stock = int(value)
            if stock < 0:
                raise ValueError
        except ValueError:
            await message.answer("Send a non-negative whole number or 'unlimited'.")
            return
    data = await state.get_data()
    async with SessionFactory() as session:
        async with session.begin():
            product = Product(
                name=data["name"],
                description=data["description"],
                price=Decimal(data["price"]),
                stock_quantity=stock,
                is_active=True,
            )
            session.add(product)
            await session.flush()
            await record_admin(session, message.from_user.id, "product_added", f"product_id={product.id}; name={product.name}; price={product.price}")
    await message.answer("Product/service added to the catalogue.")
    await state.clear()


@router.message(ProductFlow.edit_value)
async def product_edit_value(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    value = (message.text or "").strip()
    try:
        async with SessionFactory() as session:
            async with session.begin():
                product = await session.get(Product, data["product_id"], with_for_update=True)
                if product is None:
                    raise ValueError("Product not found.")
                field = data["field"]
                if field == "name":
                    if not 1 <= len(value) <= 120:
                        raise ValueError("Name must be 1–120 characters.")
                    product.name = value
                elif field == "description":
                    product.description = "" if value == "/clear" else value
                    if len(product.description) > 2000:
                        raise ValueError("Description must be 2,000 characters or less.")
                elif field == "price":
                    price = Decimal(value)
                    if not price.is_finite() or price < 0 or price > Decimal("10000000"):
                        raise ValueError("Price must be between ₹0 and ₹1,00,00,000.")
                    product.price = price.quantize(Decimal("0.01"))
                elif value.lower() == "unlimited":
                    product.stock_quantity = None
                else:
                    stock = int(value)
                    if stock < 0:
                        raise ValueError("Stock cannot be negative.")
                    product.stock_quantity = stock
                await record_admin(session, message.from_user.id, "product_edited", f"product_id={product.id}; field={field}; value={value}")
        await message.answer("Product updated.")
        await state.clear()
    except (ValueError, InvalidOperation) as exc:
        await message.answer(str(exc))


@router.callback_query(F.data.startswith("setting:"))
async def setting_prompt(callback: CallbackQuery, state: FSMContext) -> None:
    if not admin_only(callback.from_user.id):
        await callback.answer("Not authorized.", show_alert=True)
        return
    field = callback.data.split(":", 1)[1]
    if field == "qr":
        await state.set_state(SettingFlow.value)
        await state.update_data(setting_key="upi_qr_file_id")
        await callback.message.answer("Upload the UPI QR as a Telegram photo. This replaces the current QR.")
    else:
        await state.set_state(SettingFlow.value)
        await state.update_data(setting_key={"upi": "upi_id", "referral": "referral_commission_percent", "support": "support_details"}[field])
        prompts = {
            "upi": "Send the UPI ID to show users, or /clear to remove it.",
            "referral": "Send commission percentage from 0 to 100 (credited only after a referred deposit is verified).",
            "support": "Send support contact details users should see.",
        }
        await callback.message.answer(prompts[field])
    await callback.answer()


@router.message(SettingFlow.value, F.photo)
async def setting_qr_upload(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    if data.get("setting_key") != "upi_qr_file_id":
        await message.answer("This setting expects text. Send /cancel to stop.")
        return
    file_id = message.photo[-1].file_id
    async with SessionFactory() as session:
        async with session.begin():
            await set_setting(session, "upi_qr_file_id", file_id)
            await record_admin(session, message.from_user.id, "upi_qr_updated", "Telegram photo file id stored")
    await message.answer("UPI QR code updated.")
    await state.clear()


@router.message(SettingFlow.value)
async def setting_value(message: Message, state: FSMContext) -> None:
    if not admin_only(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    key = data.get("setting_key")
    value = (message.text or "").strip()
    if key == "upi_qr_file_id":
        await message.answer("Please upload the QR as a photo.")
        return
    if key == "upi_id" and value == "/clear":
        value = ""
    elif key == "upi_id" and (len(value) > 128 or "@" not in value or any(ch.isspace() for ch in value)):
        await message.answer("Enter a valid UPI ID or /clear.")
        return
    elif key == "referral_commission_percent":
        try:
            pct = Decimal(value)
            if not pct.is_finite() or not 0 <= pct <= 100:
                raise ValueError
        except (InvalidOperation, ValueError):
            await message.answer("Commission must be a number between 0 and 100.")
            return
        value = str(pct.normalize())
    elif key == "support_details" and len(value) > 1000:
        await message.answer("Support details must be 1,000 characters or less.")
        return
    async with SessionFactory() as session:
        async with session.begin():
            await set_setting(session, key, value)
            await record_admin(session, message.from_user.id, "setting_updated", f"setting={key}")
    await message.answer("Setting updated.")
    await state.clear()
