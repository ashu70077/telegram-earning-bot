from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    telegram_bot_token: str
    admin_telegram_id: int
    database_url: str
    log_level: str = "INFO"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    if not settings.telegram_bot_token or settings.admin_telegram_id <= 0:
        raise ValueError("TELEGRAM_BOT_TOKEN and a positive ADMIN_TELEGRAM_ID are required.")
    if not settings.database_url:
        raise ValueError("DATABASE_URL is required.")
    return settings
