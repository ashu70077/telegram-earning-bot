from decimal import Decimal, InvalidOperation


def parse_amount(value: str) -> Decimal:
    try:
        amount = Decimal(value.strip().replace(",", ""))
    except InvalidOperation as exc:
        raise ValueError("Enter an amount using digits, for example 200 or 200.50.") from exc
    if not amount.is_finite() or amount < Decimal("1.00") or amount > Decimal("1000000.00"):
        raise ValueError("Amount must be between ₹1 and ₹10,00,000.")
    if amount.as_tuple().exponent < -2:
        raise ValueError("Use no more than two decimal places.")
    return amount.quantize(Decimal("0.01"))


def is_valid_upi_id(value: str) -> bool:
    if value.count("@") != 1 or any(ch.isspace() for ch in value):
        return False
    username, provider = value.split("@", 1)
    return (
        1 <= len(value) <= 128
        and bool(username)
        and bool(provider)
    )
