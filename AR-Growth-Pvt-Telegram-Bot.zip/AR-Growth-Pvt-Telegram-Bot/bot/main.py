import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from sqlalchemy import text

from bot.config import get_settings
from bot.db import SessionFactory, engine
from bot.handlers.admin import router as admin_router
from bot.handlers.user import router as user_router
from bot.services import seed_defaults


async def main() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    logger = logging.getLogger("ar_growth_bot")

    # Migrations are deliberately run as a separate setup command, never at runtime.
    async with SessionFactory() as session:
        async with session.begin():
            await session.execute(text("SELECT 1"))
            await seed_defaults(session)

    bot = Bot(token=settings.telegram_bot_token)
    dispatcher = Dispatcher(storage=MemoryStorage())
    dispatcher.include_router(admin_router)
    dispatcher.include_router(user_router)
    try:
        bot_info = await bot.get_me()
        logger.info("Starting Telegram polling as @%s", bot_info.username)
        await dispatcher.start_polling(bot, allowed_updates=dispatcher.resolve_used_update_types())
    finally:
        await bot.session.close()
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
