from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

BTN_VIP = "👑 VIP Plans"
BTN_PRODUCTS = "🛍 Products"
BTN_DEPOSIT = "💳 Deposit"
BTN_WITHDRAW = "💸 Withdraw"
BTN_ACCOUNT = "👤 My Account"
BTN_HISTORY = "📜 History"
BTN_DAILY_CLAIM = "💎 Daily Claim"
BTN_REFERRAL = "🤝 Referral"
BTN_SUPPORT = "🆘 Support"
BTN_ADMIN = "🛡 Admin Panel"


def user_menu(is_admin: bool = False) -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=BTN_VIP)],
        [KeyboardButton(text=BTN_DEPOSIT), KeyboardButton(text=BTN_WITHDRAW)],
        [KeyboardButton(text=BTN_DAILY_CLAIM)],
        [KeyboardButton(text=BTN_ACCOUNT), KeyboardButton(text=BTN_HISTORY)],
        [KeyboardButton(text=BTN_REFERRAL), KeyboardButton(text=BTN_SUPPORT)],
    ]
    if is_admin:
        rows.append([KeyboardButton(text=BTN_ADMIN)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⏳ Pending Deposits", callback_data="admin:deposits")],
            [InlineKeyboardButton(text="💸 Withdrawals", callback_data="admin:withdrawals")],
            [InlineKeyboardButton(text="👑 VIP Plans", callback_data="admin:plans")],
            [InlineKeyboardButton(text="💎 Claims & Funds", callback_data="admin:claims")],
            [InlineKeyboardButton(text="🛍 Products / Services", callback_data="admin:products")],
            [InlineKeyboardButton(text="⚙️ Payment & Support", callback_data="admin:settings")],
            [InlineKeyboardButton(text="📊 Reports", callback_data="admin:reports")],
            [InlineKeyboardButton(text="🧾 Admin Activity", callback_data="admin:logs")],
        ]
    )


def back_to_admin() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ Admin Panel", callback_data="admin:home")]]
    )
