from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "argrowth_users"

    telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None] = mapped_column(String(64))
    first_name: Mapped[str] = mapped_column(String(128), default="")
    balance: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=Decimal("0.00"))
    referred_by: Mapped[int | None] = mapped_column(ForeignKey("argrowth_users.telegram_id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class VIPPlan(Base):
    __tablename__ = "argrowth_vip_plans"
    __table_args__ = (
        CheckConstraint("price >= 0", name="ck_argrowth_vip_price_nonnegative"),
        CheckConstraint("daily_claim_amount >= 0", name="ck_argrowth_vip_claim_amount_nonnegative"),
        CheckConstraint("claim_interval_hours > 0", name="ck_argrowth_vip_claim_interval_positive"),
        CheckConstraint("claim_max_amount >= 0", name="ck_argrowth_vip_claim_max_nonnegative"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    duration_days: Mapped[int] = mapped_column(Integer, default=30)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, unique=True)
    daily_claim_amount: Mapped[Decimal] = mapped_column(
        Numeric(12, 2), default=Decimal("0.00"), server_default="0.00"
    )
    claim_interval_hours: Mapped[int] = mapped_column(Integer, default=24, server_default="24")
    claim_max_amount: Mapped[Decimal] = mapped_column(
        Numeric(12, 2), default=Decimal("0.00"), server_default="0.00"
    )


class Product(Base):
    __tablename__ = "argrowth_products"
    __table_args__ = (CheckConstraint("price >= 0", name="ck_argrowth_product_price_nonnegative"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    stock_quantity: Mapped[int | None] = mapped_column(Integer)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Deposit(Base):
    __tablename__ = "argrowth_deposits"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_argrowth_deposit_amount_positive"),
        UniqueConstraint("utr", name="uq_argrowth_deposit_utr"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    utr: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="pending")
    rejection_reason: Mapped[str | None] = mapped_column(Text)
    reviewed_by: Mapped[int | None] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Withdrawal(Base):
    __tablename__ = "argrowth_withdrawals"
    __table_args__ = (CheckConstraint("amount > 0", name="ck_argrowth_withdrawal_amount_positive"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    upi_id: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(24), default="pending")
    rejection_reason: Mapped[str | None] = mapped_column(Text)
    payment_reference: Mapped[str | None] = mapped_column(String(128))
    reviewed_by: Mapped[int | None] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class WalletEntry(Base):
    __tablename__ = "argrowth_wallet_entries"
    __table_args__ = (
        UniqueConstraint("reference_type", "reference_id", "kind", name="uq_argrowth_ledger_reference"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    kind: Mapped[str] = mapped_column(String(32), nullable=False)
    reference_type: Mapped[str] = mapped_column(String(24), nullable=False)
    reference_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Order(Base):
    __tablename__ = "argrowth_orders"
    __table_args__ = (
        UniqueConstraint("user_id", "vip_plan_id", name="uq_argrowth_order_user_vip_plan_once"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), index=True)
    product_id: Mapped[int | None] = mapped_column(ForeignKey("argrowth_products.id", ondelete="SET NULL"))
    vip_plan_id: Mapped[int | None] = mapped_column(ForeignKey("argrowth_vip_plans.id"))
    product_name: Mapped[str] = mapped_column(String(120), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class VIPMembership(Base):
    __tablename__ = "argrowth_vip_memberships"

    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), primary_key=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("argrowth_vip_plans.id"))
    plan_name: Mapped[str] = mapped_column(String(80), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class VIPEntitlement(Base):
    __tablename__ = "argrowth_vip_entitlements"
    __table_args__ = (
        CheckConstraint("daily_claim_amount >= 0", name="ck_argrowth_entitlement_claim_nonnegative"),
        CheckConstraint("claim_interval_hours > 0", name="ck_argrowth_entitlement_interval_positive"),
        CheckConstraint("claim_max_amount >= 0", name="ck_argrowth_entitlement_max_nonnegative"),
    )

    order_id: Mapped[int] = mapped_column(
        ForeignKey("argrowth_orders.id", ondelete="CASCADE"), primary_key=True
    )
    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), index=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey("argrowth_vip_plans.id"))
    plan_name: Mapped[str] = mapped_column(String(80), nullable=False)
    purchased_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    daily_claim_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    claim_interval_hours: Mapped[int] = mapped_column(Integer, nullable=False)
    claim_max_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)


class ClaimPool(Base):
    __tablename__ = "argrowth_claim_pool"
    __table_args__ = (
        CheckConstraint("available_funds >= 0", name="ck_argrowth_claim_pool_funds_nonnegative"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    available_funds: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), nullable=False, default=Decimal("0.00"), server_default="0.00"
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class ClaimFunding(Base):
    __tablename__ = "argrowth_claim_fundings"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_argrowth_claim_funding_positive"),
        UniqueConstraint("funding_reference", name="uq_argrowth_claim_funding_reference"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    funding_reference: Mapped[str] = mapped_column(String(128), nullable=False)
    admin_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class DailyClaim(Base):
    __tablename__ = "argrowth_daily_claims"
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_argrowth_daily_claim_amount_positive"),
        CheckConstraint(
            "status IN ('pending', 'paid', 'rejected')",
            name="ck_argrowth_daily_claim_status",
        ),
        UniqueConstraint("payout_reference", name="uq_argrowth_daily_claim_payout_reference"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entitlement_order_id: Mapped[int] = mapped_column(
        ForeignKey("argrowth_vip_entitlements.order_id"), index=True
    )
    user_id: Mapped[int] = mapped_column(ForeignKey("argrowth_users.telegram_id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="pending")
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    reviewed_by: Mapped[int | None] = mapped_column(BigInteger)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    payout_reference: Mapped[str | None] = mapped_column(String(128))
    rejection_reason: Mapped[str | None] = mapped_column(Text)


class Setting(Base):
    __tablename__ = "argrowth_settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class AdminActivity(Base):
    __tablename__ = "argrowth_admin_activity"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admin_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    action: Mapped[str] = mapped_column(String(80), nullable=False)
    details: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
