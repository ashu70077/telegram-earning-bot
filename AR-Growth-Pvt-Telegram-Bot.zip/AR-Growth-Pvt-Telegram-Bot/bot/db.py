from collections.abc import AsyncIterator

from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from bot.config import get_settings


def _async_database_url(url: str) -> str:
    parsed = make_url(url)
    driver = "postgresql+asyncpg" if parsed.drivername in {"postgres", "postgresql"} else parsed.drivername
    query = dict(parsed.query)
    sslmode = query.pop("sslmode", None)
    if sslmode and sslmode.lower() != "disable":
        query.setdefault("ssl", sslmode.lower())
    return parsed.set(drivername=driver).set(query=query).render_as_string(hide_password=False)


engine = create_async_engine(
    _async_database_url(get_settings().database_url),
    pool_pre_ping=True,
    pool_size=5,
    max_overflow=5,
)
SessionFactory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def session_scope() -> AsyncIterator[AsyncSession]:
    async with SessionFactory() as session:
        yield session
