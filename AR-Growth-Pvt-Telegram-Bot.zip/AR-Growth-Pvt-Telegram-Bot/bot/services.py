from datetime import datetime, timedelta, timezone
from decimal import Decimal
from math import ceil

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from bot.models import (
    AdminActivity,
    ClaimFunding,
    ClaimPool,
    DailyClaim,
    Deposit,
    Order,
    Product,
    Setting,
    User,
    VIPEntitlement,
    VIPMembership,
    VIPPlan,
    WalletEntry,
    Withdrawal,
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


async def get_setting(session: AsyncSession, key: str, default: str = "") -> str:
    row = await session.get(Setting, key)
    return row.value if row else default


async def set_setting(session: AsyncSession, key: str, value: str) -> None:
    row = await session.get(Setting, key)
    if row is None:
        session.add(Setting(key=key, value=value))
    else:
        row.value = value


async def record_admin(session: AsyncSession, admin_id: int, action: str, details: str = "") -> None:
    session.add(AdminActivity(admin_id=admin_id, action=action, details=details[:2000]))


async def ensure_user(
    session: AsyncSession, telegram_id: int, username: str | None, first_name: str, referrer_id: int | None
) -> User:
    user = await session.get(User, telegram_id)
    if user is None:
        if referrer_id == telegram_id or (referrer_id and await session.get(User, referrer_id) is None):
            referrer_id = None
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name[:128],
            referred_by=referrer_id,
            balance=Decimal("0.00"),
        )
        session.add(user)
        await session.flush()
    else:
        user.username = username
        user.first_name = first_name[:128]
    return user


async def create_deposit(session: AsyncSession, user_id: int, amount: Decimal, utr: str) -> Deposit:
    clean_utr = utr.strip().upper()
    if not clean_utr or len(clean_utr) > 64:
        raise ValueError("Enter a valid UTR/reference up to 64 characters.")
    try:
        async with session.begin_nested():
            deposit = Deposit(user_id=user_id, amount=amount, utr=clean_utr, status="pending")
            session.add(deposit)
            await session.flush()
    except IntegrityError as exc:
        raise ValueError("That UTR/reference has already been submitted.") from exc
    return deposit


async def review_deposit(
    session: AsyncSession, deposit_id: int, admin_id: int, approve: bool, reason: str = ""
) -> tuple[Deposit, int | None, Decimal]:
    deposit = await session.scalar(select(Deposit).where(Deposit.id == deposit_id).with_for_update())
    if deposit is None:
        raise ValueError("Deposit request not found.")
    if deposit.status != "pending":
        raise ValueError("This deposit has already been reviewed.")
    user = await session.scalar(select(User).where(User.telegram_id == deposit.user_id).with_for_update())
    if user is None:
        raise ValueError("Deposit owner no longer exists.")
    deposit.reviewed_by = admin_id
    deposit.reviewed_at = utcnow()
    referrer_id: int | None = None
    commission = Decimal("0.00")
    if approve:
        deposit.status = "approved"
        user.balance += deposit.amount
        session.add(
            WalletEntry(
                user_id=user.telegram_id,
                amount=deposit.amount,
                kind="deposit",
                reference_type="deposit",
                reference_id=deposit.id,
                note=f"Verified deposit {deposit.utr}",
            )
        )
        if user.referred_by:
            referrer = await session.scalar(
                select(User).where(User.telegram_id == user.referred_by).with_for_update()
            )
            percent = Decimal(await get_setting(session, "referral_commission_percent", "20"))
            if referrer is not None and Decimal("0") <= percent <= Decimal("100"):
                commission = (deposit.amount * percent / Decimal("100")).quantize(Decimal("0.01"))
                if commission > 0:
                    referrer.balance += commission
                    referrer_id = referrer.telegram_id
                    session.add(
                        WalletEntry(
                            user_id=referrer.telegram_id,
                            amount=commission,
                            kind="referral_commission",
                            reference_type="deposit",
                            reference_id=deposit.id,
                            note=f"Referral commission for verified deposit #{deposit.id}",
                        )
                    )
    else:
        deposit.status = "rejected"
        deposit.rejection_reason = reason[:500] or "Unable to verify payment."
    await session.flush()
    return deposit, referrer_id, commission


async def request_withdrawal(
    session: AsyncSession, user_id: int, amount: Decimal, upi_id: str
) -> Withdrawal:
    user = await session.scalar(select(User).where(User.telegram_id == user_id).with_for_update())
    if user is None:
        raise ValueError("Account not found.")
    if user.balance < amount:
        raise ValueError("Insufficient available balance.")
    request = Withdrawal(user_id=user_id, amount=amount, upi_id=upi_id.strip(), status="pending")
    session.add(request)
    await session.flush()
    user.balance -= amount
    session.add(
        WalletEntry(
            user_id=user_id,
            amount=-amount,
            kind="withdrawal_reserved",
            reference_type="withdrawal",
            reference_id=request.id,
            note="Withdrawal request reserved for admin review",
        )
    )
    return request


async def review_withdrawal(
    session: AsyncSession,
    withdrawal_id: int,
    admin_id: int,
    action: str,
    reason_or_reference: str = "",
) -> Withdrawal:
    request = await session.scalar(
        select(Withdrawal).where(Withdrawal.id == withdrawal_id).with_for_update()
    )
    if request is None:
        raise ValueError("Withdrawal request not found.")
    if request.status != "pending":
        raise ValueError("This withdrawal has already been actioned.")
    request.reviewed_by = admin_id
    request.reviewed_at = utcnow()
    if action == "approve":
        request.status = "approved"
    elif action == "paid":
        raise ValueError("A pending request must first be approved.")
    elif action == "reject":
        user = await session.scalar(select(User).where(User.telegram_id == request.user_id).with_for_update())
        if user is None:
            raise ValueError("Withdrawal owner no longer exists.")
        user.balance += request.amount
        request.status = "rejected"
        request.rejection_reason = reason_or_reference[:500] or "Request rejected."
        session.add(
            WalletEntry(
                user_id=user.telegram_id,
                amount=request.amount,
                kind="withdrawal_refund",
                reference_type="withdrawal",
                reference_id=request.id,
                note="Refund for rejected withdrawal",
            )
        )
    else:
        raise ValueError("Unknown withdrawal action.")
    return request


async def mark_withdrawal_paid(
    session: AsyncSession, withdrawal_id: int, admin_id: int, payment_reference: str
) -> Withdrawal:
    request = await session.scalar(
        select(Withdrawal).where(Withdrawal.id == withdrawal_id).with_for_update()
    )
    if request is None or request.status != "approved":
        raise ValueError("Only an approved withdrawal can be marked paid.")
    request.status = "paid"
    request.payment_reference = payment_reference[:128]
    request.paid_at = utcnow()
    request.reviewed_by = admin_id
    request.reviewed_at = utcnow()
    return request


async def buy_product(session: AsyncSession, user_id: int, product_id: int) -> Order:
    product = await session.scalar(select(Product).where(Product.id == product_id).with_for_update())
    user = await session.scalar(select(User).where(User.telegram_id == user_id).with_for_update())
    if user is None or product is None or not product.is_active:
        raise ValueError("This product is not available.")
    if product.stock_quantity is not None and product.stock_quantity <= 0:
        raise ValueError("This product is out of stock.")
    if user.balance < product.price:
        raise ValueError("Your balance is too low. Submit a deposit request first.")
    order = Order(
        user_id=user_id,
        product_id=product.id,
        product_name=product.name,
        amount=product.price,
    )
    session.add(order)
    await session.flush()
    user.balance -= product.price
    if product.stock_quantity is not None:
        product.stock_quantity -= 1
    session.add(
        WalletEntry(
            user_id=user_id,
            amount=-product.price,
            kind="product_purchase",
            reference_type="order",
            reference_id=order.id,
            note=f"Purchase: {product.name}",
        )
    )
    return order


async def buy_vip_plan(session: AsyncSession, user_id: int, plan_id: int) -> VIPMembership:
    plan = await session.scalar(select(VIPPlan).where(VIPPlan.id == plan_id).with_for_update())
    user = await session.scalar(select(User).where(User.telegram_id == user_id).with_for_update())
    if user is None or plan is None or not plan.is_active:
        raise ValueError("This VIP plan is not available.")
    previous_purchase = await session.scalar(
        select(Order.id)
        .where(Order.user_id == user_id, Order.vip_plan_id == plan.id)
        .limit(1)
    )
    if previous_purchase is not None:
        raise ValueError("You have already purchased this VIP plan. Each plan can only be purchased once.")
    if user.balance < plan.price:
        raise ValueError("Your balance is too low. Submit a deposit request first.")
    user.balance -= plan.price
    order = Order(
        user_id=user_id,
        product_id=None,
        vip_plan_id=plan.id,
        product_name=f"VIP membership: {plan.name}",
        amount=plan.price,
    )
    try:
        async with session.begin_nested():
            session.add(order)
            await session.flush()
    except IntegrityError as exc:
        raise ValueError("You have already purchased this VIP plan. Each plan can only be purchased once.") from exc
    purchased_at = utcnow()
    session.add(
        VIPEntitlement(
            order_id=order.id,
            user_id=user_id,
            plan_id=plan.id,
            plan_name=plan.name,
            purchased_at=purchased_at,
            expires_at=purchased_at + timedelta(days=plan.duration_days),
            daily_claim_amount=plan.daily_claim_amount,
            claim_interval_hours=plan.claim_interval_hours,
            claim_max_amount=plan.claim_max_amount,
        )
    )
    membership = await session.get(VIPMembership, user_id, with_for_update=True)
    current_expiry = membership.expires_at if membership and membership.expires_at > utcnow() else utcnow()
    expires = current_expiry + timedelta(days=plan.duration_days)
    if membership is None:
        membership = VIPMembership(
            user_id=user_id, plan_id=plan.id, plan_name=plan.name, expires_at=expires
        )
        session.add(membership)
    else:
        membership.plan_id = plan.id
        membership.plan_name = plan.name
        membership.expires_at = expires
    await session.flush()
    session.add(
        WalletEntry(
            user_id=user_id,
            amount=-plan.price,
            kind="vip_purchase",
            reference_type="order",
            reference_id=order.id,
            note=f"VIP plan: {plan.name}",
        )
    )
    return membership


async def add_claim_pool_funding(
    session: AsyncSession, admin_id: int, amount: Decimal, funding_reference: str
) -> tuple[ClaimFunding, Decimal]:
    reference = funding_reference.strip()
    if not reference or len(reference) > 128:
        raise ValueError("Enter a valid funding reference (1–128 characters).")
    if not amount.is_finite() or amount <= 0 or amount > Decimal("100000000"):
        raise ValueError("Funding amount must be greater than ₹0 and at most ₹10,00,00,000.")
    duplicate = await session.scalar(
        select(ClaimFunding.id).where(ClaimFunding.funding_reference == reference).limit(1)
    )
    if duplicate is not None:
        raise ValueError("That funding reference has already been recorded.")
    pool = await session.scalar(select(ClaimPool).where(ClaimPool.id == 1).with_for_update())
    if pool is None:
        raise ValueError("The claim payout pool is not initialized.")
    funding = ClaimFunding(
        amount=amount.quantize(Decimal("0.01")),
        funding_reference=reference,
        admin_id=admin_id,
    )
    try:
        async with session.begin_nested():
            pool.available_funds += funding.amount
            session.add(funding)
            await session.flush()
    except IntegrityError as exc:
        raise ValueError("That funding reference has already been recorded.") from exc
    return funding, pool.available_funds


async def get_entitlement_claim_state(
    session: AsyncSession, entitlement: VIPEntitlement, now: datetime | None = None
) -> dict[str, object]:
    now = now or utcnow()
    claims = DailyClaim.entitlement_order_id == entitlement.order_id
    paid_total = Decimal(
        await session.scalar(
            select(func.coalesce(func.sum(DailyClaim.amount), 0)).where(
                claims, DailyClaim.status == "paid"
            )
        )
        or 0
    )
    pending = await session.scalar(
        select(DailyClaim)
        .where(claims, DailyClaim.status == "pending")
        .order_by(DailyClaim.requested_at.desc())
        .limit(1)
    )
    last_paid_at = await session.scalar(
        select(DailyClaim.paid_at)
        .where(claims, DailyClaim.status == "paid", DailyClaim.paid_at.is_not(None))
        .order_by(DailyClaim.paid_at.desc())
        .limit(1)
    )
    next_claim_at = (
        last_paid_at + timedelta(hours=entitlement.claim_interval_hours)
        if last_paid_at
        else entitlement.purchased_at
    )
    reserved = pending.amount if pending else Decimal("0.00")
    cap_remaining = max(
        Decimal("0.00"),
        entitlement.claim_max_amount - paid_total - reserved,
    )
    remaining_days = max(0, ceil(max(0, (entitlement.expires_at - now).total_seconds()) / 86400))
    if now >= entitlement.expires_at:
        reason = "expired"
    elif entitlement.daily_claim_amount <= 0 or entitlement.claim_max_amount <= 0:
        reason = "disabled"
    elif pending is not None:
        reason = "pending"
    elif cap_remaining < entitlement.daily_claim_amount:
        reason = "cap_reached"
    elif now < next_claim_at:
        reason = "cooldown"
    else:
        reason = "eligible"
    return {
        "paid_total": paid_total,
        "pending": pending,
        "next_claim_at": next_claim_at,
        "cap_remaining": cap_remaining,
        "remaining_days": remaining_days,
        "reason": reason,
    }


async def request_daily_claim(
    session: AsyncSession,
    user_id: int,
    entitlement_order_id: int,
    now: datetime | None = None,
) -> tuple[DailyClaim, Decimal]:
    now = now or utcnow()
    entitlement = await session.scalar(
        select(VIPEntitlement)
        .where(
            VIPEntitlement.order_id == entitlement_order_id,
            VIPEntitlement.user_id == user_id,
        )
        .with_for_update()
    )
    if entitlement is None:
        raise ValueError("No eligible VIP claim plan was found.")
    state = await get_entitlement_claim_state(session, entitlement, now)
    reason = state["reason"]
    if reason == "expired":
        raise ValueError("This plan's claim period has expired.")
    if reason == "disabled":
        raise ValueError("Daily claims are not enabled for this plan.")
    if reason == "pending":
        raise ValueError("A claim request is already awaiting payout.")
    if reason == "cap_reached":
        raise ValueError("This plan has reached its maximum claim amount.")
    if reason == "cooldown":
        next_time = state["next_claim_at"]
        raise ValueError(f"Your next claim is available after {next_time:%d %b %Y, %H:%M} UTC.")

    pool = await session.scalar(select(ClaimPool).where(ClaimPool.id == 1).with_for_update())
    if pool is None:
        raise ValueError("The claim payout pool is not initialized.")
    if pool.available_funds < entitlement.daily_claim_amount:
        raise ValueError("There are not enough verified funds in the payout pool for this claim.")

    amount = entitlement.daily_claim_amount
    pool.available_funds -= amount
    claim = DailyClaim(
        entitlement_order_id=entitlement.order_id,
        user_id=user_id,
        amount=amount,
        status="pending",
    )
    session.add(claim)
    await session.flush()
    return claim, pool.available_funds


async def mark_daily_claim_paid(
    session: AsyncSession,
    claim_id: int,
    admin_id: int,
    payout_reference: str,
    now: datetime | None = None,
) -> DailyClaim:
    reference = payout_reference.strip()
    if not 1 <= len(reference) <= 128:
        raise ValueError("Enter the actual payout reference (1–128 characters).")
    claim = await session.scalar(
        select(DailyClaim).where(DailyClaim.id == claim_id).with_for_update()
    )
    if claim is None or claim.status != "pending":
        raise ValueError("Only a pending claim can be marked paid.")
    try:
        async with session.begin_nested():
            claim.status = "paid"
            claim.payout_reference = reference
            claim.reviewed_by = admin_id
            claim.reviewed_at = now or utcnow()
            claim.paid_at = now or utcnow()
            await session.flush()
    except IntegrityError as exc:
        raise ValueError("That payout reference is already recorded.") from exc
    return claim


async def reject_daily_claim(
    session: AsyncSession, claim_id: int, admin_id: int, reason: str
) -> DailyClaim:
    claim = await session.scalar(
        select(DailyClaim).where(DailyClaim.id == claim_id).with_for_update()
    )
    if claim is None or claim.status != "pending":
        raise ValueError("Only a pending claim can be rejected.")
    pool = await session.scalar(select(ClaimPool).where(ClaimPool.id == 1).with_for_update())
    if pool is None:
        raise ValueError("The claim payout pool is not initialized.")
    pool.available_funds += claim.amount
    claim.status = "rejected"
    claim.rejection_reason = reason.strip()[:500] or "Claim rejected."
    claim.reviewed_by = admin_id
    claim.reviewed_at = utcnow()
    await session.flush()
    return claim


async def seed_defaults(session: AsyncSession) -> None:
    count = await session.scalar(select(func.count()).select_from(VIPPlan))
    if not count:
        for index in range(1, 11):
            session.add(
                VIPPlan(
                    name=f"VIP Plan {index}",
                    price=Decimal(index * 200),
                    duration_days=30,
                    is_active=True,
                    sort_order=index,
                    daily_claim_amount=Decimal("15.00") if index == 1 else Decimal("0.00"),
                    claim_interval_hours=24,
                    claim_max_amount=Decimal("450.00") if index == 1 else Decimal("0.00"),
                )
            )
    if await session.get(ClaimPool, 1) is None:
        session.add(ClaimPool(id=1, available_funds=Decimal("0.00")))
    for key, value in (
        ("upi_id", ""),
        ("upi_qr_file_id", ""),
        ("support_details", "Contact support through the administrator."),
        ("referral_commission_percent", "20"),
    ):
        if await session.get(Setting, key) is None:
            session.add(Setting(key=key, value=value))
