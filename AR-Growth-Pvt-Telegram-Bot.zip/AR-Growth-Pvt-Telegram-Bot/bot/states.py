from aiogram.fsm.state import State, StatesGroup


class DepositFlow(StatesGroup):
    amount = State()
    utr = State()


class WithdrawalFlow(StatesGroup):
    amount = State()
    upi_id = State()


class ProductFlow(StatesGroup):
    name = State()
    description = State()
    price = State()
    stock = State()
    edit_value = State()


class PlanFlow(StatesGroup):
    edit_value = State()


class SettingFlow(StatesGroup):
    value = State()


class AdminRejectFlow(StatesGroup):
    reason = State()


class PaidFlow(StatesGroup):
    reference = State()


class ClaimFundingFlow(StatesGroup):
    amount = State()
    reference = State()


class ClaimRuleFlow(StatesGroup):
    value = State()
