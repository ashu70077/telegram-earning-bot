import asyncio

from bot.db import SessionFactory, engine
from bot.services import seed_defaults


async def main() -> None:
    async with SessionFactory() as session:
        async with session.begin():
            await seed_defaults(session)
    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
