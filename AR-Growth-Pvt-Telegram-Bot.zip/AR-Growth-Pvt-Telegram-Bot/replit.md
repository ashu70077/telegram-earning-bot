# AR Growth Pvt. Telegram Bot

An aiogram Telegram bot for manually verified UPI deposits, wallet balances, withdrawals, VIP memberships, products, referrals, and Telegram-only administration.

## Run & Operate

- `python -m bot.main` — run the Telegram bot (also configured as the `AR Growth Pvt. Bot` workflow)
- `python -m bot.seed` — seed default VIP plans and settings
- `alembic upgrade head` — apply PostgreSQL schema migrations before first startup
- `pytest -q` — run validation and PostgreSQL transactional tests
- `pnpm run typecheck` — full typecheck across all packages
- Required Replit Secrets: `TELEGRAM_BOT_TOKEN`, `ADMIN_TELEGRAM_ID`
- PostgreSQL: uses the Replit-provided `DATABASE_URL`

## Stack

- Python 3.11, aiogram 3, SQLAlchemy async, asyncpg, Alembic
- PostgreSQL stores Telegram accounts, ledger entries, requests, plans, products, settings, and admin activity
- The app does not run DDL at bot startup; migrations are applied explicitly

## Where things live

- `bot/` — configuration, handlers, database models, services, and validation
- `migrations/` — Alembic environment and schema revisions
- `tests/` — validation and PostgreSQL transactional tests
- `README.md` — Replit setup, payment safeguards, and operator instructions

## Architecture decisions

- Deposits are credited only after an admin verifies the UTR and approves the request.
- Withdrawal funds are reserved on request, refunded on rejection, and marked paid only after an admin records a payment reference.
- Migrations are restricted to the `argrowth_` table prefix to avoid touching the existing API schema.
- Product records are archived from the storefront instead of physically deleted so order history remains intact.

## Product

Ten editable VIP memberships are seeded at ₹200–₹2,000. The product list starts empty and must be populated with real offerings. Referral commission is configurable and is credited only from verified referred deposits. The bot does not promise profit or returns.

## User preferences

- Keep required credentials in Replit Secrets; do not put them in source code or chat.

## Gotchas

- Run `alembic upgrade head` before starting after a schema revision.
- `DATABASE_URL` may include `sslmode`; the asyncpg URL adapter translates this to its supported `ssl` connection argument.

## Pointers

- This project retains the original pnpm API and design artifacts alongside the Python bot.
