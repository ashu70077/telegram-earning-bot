"""Track VIP plan purchases and prevent repeat purchases.

Revision ID: 2c4a91d7e630
Revises: fce442f5be19
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "2c4a91d7e630"
down_revision: Union[str, None] = "fce442f5be19"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("argrowth_orders", sa.Column("vip_plan_id", sa.Integer(), nullable=True))
    op.create_foreign_key(
        "fk_argrowth_orders_vip_plan_id_argrowth_vip_plans",
        "argrowth_orders",
        "argrowth_vip_plans",
        ["vip_plan_id"],
        ["id"],
    )

    # Preserve one legacy purchase per user and plan when the old plan name
    # still matches. Older purchases are immutable snapshots in argrowth_orders.
    op.execute(
        sa.text(
            """
            WITH candidates AS (
                SELECT o.id,
                       o.user_id,
                       p.id AS plan_id,
                       COUNT(*) OVER (PARTITION BY o.id) AS matching_plans,
                       ROW_NUMBER() OVER (
                           PARTITION BY o.user_id, p.id
                           ORDER BY o.created_at DESC, o.id DESC
                       ) AS purchase_rank
                FROM argrowth_orders AS o
                JOIN argrowth_vip_plans AS p
                  ON o.product_id IS NULL
                 AND o.product_name = 'VIP membership: ' || p.name
            )
            UPDATE argrowth_orders AS o
               SET vip_plan_id = candidates.plan_id
              FROM candidates
             WHERE candidates.id = o.id
               AND candidates.matching_plans = 1
               AND candidates.purchase_rank = 1
            """
        )
    )

    # The membership row records the user's latest plan even if that plan was
    # renamed after purchase, so use it to backfill a matching unassigned order.
    op.execute(
        sa.text(
            """
            WITH legacy_membership AS (
                SELECT m.user_id, m.plan_id, prior_order.id AS order_id
                  FROM argrowth_vip_memberships AS m
                  JOIN LATERAL (
                      SELECT o.id
                        FROM argrowth_orders AS o
                       WHERE o.user_id = m.user_id
                         AND o.product_id IS NULL
                         AND o.vip_plan_id IS NULL
                       ORDER BY o.created_at DESC, o.id DESC
                       LIMIT 1
                  ) AS prior_order ON TRUE
                 WHERE NOT EXISTS (
                       SELECT 1
                         FROM argrowth_orders AS existing
                        WHERE existing.user_id = m.user_id
                          AND existing.vip_plan_id = m.plan_id
                 )
            )
            UPDATE argrowth_orders AS o
               SET vip_plan_id = legacy_membership.plan_id
              FROM legacy_membership
             WHERE legacy_membership.order_id = o.id
            """
        )
    )

    op.create_unique_constraint(
        "uq_argrowth_order_user_vip_plan_once",
        "argrowth_orders",
        ["user_id", "vip_plan_id"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_argrowth_order_user_vip_plan_once",
        "argrowth_orders",
        type_="unique",
    )
    op.drop_constraint(
        "fk_argrowth_orders_vip_plan_id_argrowth_vip_plans",
        "argrowth_orders",
        type_="foreignkey",
    )
    op.drop_column("argrowth_orders", "vip_plan_id")
