"""Add funded daily claims and payout-pool accounting.

Revision ID: 79f2c1a3d508
Revises: 2c4a91d7e630
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "79f2c1a3d508"
down_revision: Union[str, None] = "2c4a91d7e630"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "argrowth_vip_plans",
        sa.Column("daily_claim_amount", sa.Numeric(12, 2), nullable=False, server_default="0.00"),
    )
    op.add_column(
        "argrowth_vip_plans",
        sa.Column("claim_interval_hours", sa.Integer(), nullable=False, server_default="24"),
    )
    op.add_column(
        "argrowth_vip_plans",
        sa.Column("claim_max_amount", sa.Numeric(12, 2), nullable=False, server_default="0.00"),
    )
    op.create_check_constraint(
        "ck_argrowth_vip_claim_amount_nonnegative",
        "argrowth_vip_plans",
        "daily_claim_amount >= 0",
    )
    op.create_check_constraint(
        "ck_argrowth_vip_claim_interval_positive",
        "argrowth_vip_plans",
        "claim_interval_hours > 0",
    )
    op.create_check_constraint(
        "ck_argrowth_vip_claim_max_nonnegative",
        "argrowth_vip_plans",
        "claim_max_amount >= 0",
    )
    op.execute(
        sa.text(
            """
            UPDATE argrowth_vip_plans
               SET price = 200.00,
                   duration_days = 30,
                   daily_claim_amount = 15.00,
                   claim_interval_hours = 24,
                   claim_max_amount = 450.00
             WHERE sort_order = 1
            """
        )
    )

    op.create_table(
        "argrowth_vip_entitlements",
        sa.Column("order_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("plan_id", sa.Integer(), nullable=False),
        sa.Column("plan_name", sa.String(length=80), nullable=False),
        sa.Column("purchased_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("daily_claim_amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("claim_interval_hours", sa.Integer(), nullable=False),
        sa.Column("claim_max_amount", sa.Numeric(12, 2), nullable=False),
        sa.CheckConstraint(
            "daily_claim_amount >= 0", name="ck_argrowth_entitlement_claim_nonnegative"
        ),
        sa.CheckConstraint(
            "claim_interval_hours > 0", name="ck_argrowth_entitlement_interval_positive"
        ),
        sa.CheckConstraint(
            "claim_max_amount >= 0", name="ck_argrowth_entitlement_max_nonnegative"
        ),
        sa.ForeignKeyConstraint(["order_id"], ["argrowth_orders.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["argrowth_users.telegram_id"]),
        sa.ForeignKeyConstraint(["plan_id"], ["argrowth_vip_plans.id"]),
        sa.PrimaryKeyConstraint("order_id"),
    )
    op.create_index(
        "ix_argrowth_vip_entitlements_user_id",
        "argrowth_vip_entitlements",
        ["user_id"],
    )
    op.create_index(
        "ix_argrowth_vip_entitlements_expires_at",
        "argrowth_vip_entitlements",
        ["expires_at"],
    )
    op.execute(
        sa.text(
            """
            INSERT INTO argrowth_vip_entitlements (
                order_id, user_id, plan_id, plan_name, purchased_at, expires_at,
                daily_claim_amount, claim_interval_hours, claim_max_amount
            )
            SELECT o.id, o.user_id, p.id, p.name, o.created_at,
                   o.created_at + (p.duration_days * INTERVAL '1 day'),
                   p.daily_claim_amount, p.claim_interval_hours, p.claim_max_amount
              FROM argrowth_orders AS o
              JOIN argrowth_vip_plans AS p ON p.id = o.vip_plan_id
             WHERE o.vip_plan_id IS NOT NULL
            """
        )
    )

    op.create_table(
        "argrowth_claim_pool",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("available_funds", sa.Numeric(14, 2), nullable=False, server_default="0.00"),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint(
            "available_funds >= 0", name="ck_argrowth_claim_pool_funds_nonnegative"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.execute(
        sa.text(
            "INSERT INTO argrowth_claim_pool (id, available_funds) VALUES (1, 0.00)"
        )
    )

    op.create_table(
        "argrowth_claim_fundings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("funding_reference", sa.String(length=128), nullable=False),
        sa.Column("admin_id", sa.BigInteger(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.CheckConstraint("amount > 0", name="ck_argrowth_claim_funding_positive"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("funding_reference", name="uq_argrowth_claim_funding_reference"),
    )

    op.create_table(
        "argrowth_daily_claims",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("entitlement_order_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.BigInteger(), nullable=False),
        sa.Column("amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False),
        sa.Column("requested_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("reviewed_by", sa.BigInteger(), nullable=True),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("paid_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("payout_reference", sa.String(length=128), nullable=True),
        sa.Column("rejection_reason", sa.Text(), nullable=True),
        sa.CheckConstraint("amount > 0", name="ck_argrowth_daily_claim_amount_positive"),
        sa.CheckConstraint(
            "status IN ('pending', 'paid', 'rejected')",
            name="ck_argrowth_daily_claim_status",
        ),
        sa.ForeignKeyConstraint(
            ["entitlement_order_id"], ["argrowth_vip_entitlements.order_id"]
        ),
        sa.ForeignKeyConstraint(["user_id"], ["argrowth_users.telegram_id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "payout_reference", name="uq_argrowth_daily_claim_payout_reference"
        ),
    )
    op.create_index(
        "ix_argrowth_daily_claims_entitlement_order_id",
        "argrowth_daily_claims",
        ["entitlement_order_id"],
    )
    op.create_index(
        "ix_argrowth_daily_claims_user_id",
        "argrowth_daily_claims",
        ["user_id"],
    )


def downgrade() -> None:
    op.drop_index("ix_argrowth_daily_claims_user_id", table_name="argrowth_daily_claims")
    op.drop_index(
        "ix_argrowth_daily_claims_entitlement_order_id", table_name="argrowth_daily_claims"
    )
    op.drop_table("argrowth_daily_claims")
    op.drop_table("argrowth_claim_fundings")
    op.drop_table("argrowth_claim_pool")
    op.drop_index(
        "ix_argrowth_vip_entitlements_expires_at", table_name="argrowth_vip_entitlements"
    )
    op.drop_index(
        "ix_argrowth_vip_entitlements_user_id", table_name="argrowth_vip_entitlements"
    )
    op.drop_table("argrowth_vip_entitlements")
    op.drop_constraint(
        "ck_argrowth_vip_claim_max_nonnegative", "argrowth_vip_plans", type_="check"
    )
    op.drop_constraint(
        "ck_argrowth_vip_claim_interval_positive", "argrowth_vip_plans", type_="check"
    )
    op.drop_constraint(
        "ck_argrowth_vip_claim_amount_nonnegative", "argrowth_vip_plans", type_="check"
    )
    op.drop_column("argrowth_vip_plans", "claim_max_amount")
    op.drop_column("argrowth_vip_plans", "claim_interval_hours")
    op.drop_column("argrowth_vip_plans", "daily_claim_amount")
